<?php
session_start();
$pageTitle = "AI-Solutions – Innovating the Digital Employee Experience";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/nav.php'; ?>

<!-- HERO -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-badge">🚀 AI-Powered Innovation</div>
    <h1>The Future of <span>Digital Employee</span> Experience</h1>
    <p>AI-Solutions empowers businesses with intelligent virtual assistants, rapid prototyping, and AI-driven software solutions that transform the way your teams work.</p>
    <div class="hero-btns">
      <a href="contact.php" class="btn btn-primary">📅 Schedule a Demo</a>
      <a href="services.php" class="btn btn-outline">Explore Services</a>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-bar">
  <div class="section-inner">
    <div class="stat-item"><div class="stat-num">500+</div><div class="stat-label">Businesses Served</div></div>
    <div class="stat-item"><div class="stat-num">98%</div><div class="stat-label">Client Satisfaction</div></div>
    <div class="stat-item"><div class="stat-num">24/7</div><div class="stat-label">AI Support</div></div>
    <div class="stat-item"><div class="stat-num">40+</div><div class="stat-label">Countries Reached</div></div>
  </div>
</div>

<!-- SERVICES OVERVIEW -->
<section>
  <div class="section-inner">
    <div class="section-header">
      <div class="section-tag">What We Do</div>
      <h2 class="section-title">AI-Powered Software Solutions</h2>
      <p class="section-sub">From virtual assistants to rapid prototyping — we deliver intelligent tools that accelerate your business.</p>
    </div>
    <div class="cards-grid">
      <div class="card">
        <div class="card-icon">🤖</div>
        <h3>AI Virtual Assistant</h3>
        <p>Deploy intelligent chatbots that understand context, handle complex queries, and seamlessly escalate to human agents when needed.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
      <div class="card">
        <div class="card-icon">⚡</div>
        <h3>Rapid Prototyping</h3>
        <p>Turn your ideas into working prototypes in days, not months. Our AI-assisted development process dramatically reduces time-to-market.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
      <div class="card">
        <div class="card-icon">🔄</div>
        <h3>Process Automation</h3>
        <p>Identify and automate repetitive tasks across your organisation, freeing your team to focus on high-value strategic work.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
      <div class="card">
        <div class="card-icon">📊</div>
        <h3>Analytics &amp; Insights</h3>
        <p>Unlock the power of your data with AI-driven analytics dashboards that surface actionable insights in real time.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
      <div class="card">
        <div class="card-icon">🔒</div>
        <h3>Secure by Design</h3>
        <p>Every solution we build is architected with enterprise-grade security, compliance, and data privacy at its core.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
      <div class="card">
        <div class="card-icon">🌐</div>
        <h3>Global Scalability</h3>
        <p>Built for growth. Our cloud-native infrastructure scales effortlessly from startup to enterprise, wherever you are in the world.</p>
        <br><a href="services.php" style="color:var(--pl);font-weight:600;font-size:.9rem;text-decoration:none">Learn more →</a>
      </div>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="bg-light">
  <div class="section-inner">
    <div class="section-header">
      <div class="section-tag">Our Process</div>
      <h2 class="section-title">How We Work</h2>
      <p class="section-sub">A structured, agile approach that delivers results fast.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.5rem;text-align:center">
      <?php
      $steps = [
        ['01','🤝','Discover','We meet with your team to understand your challenges, goals, and existing systems.'],
        ['02','🎨','Design','Our experts design a tailored AI solution that fits your workflow and requirements.'],
        ['03','🛠️','Build','We develop and rigorously test the solution using agile, iterative development.'],
        ['04','🚀','Deploy','We deploy to your environment, provide training, and ensure a smooth go-live.'],
        ['05','📈','Optimise','Ongoing monitoring and AI model improvements to keep performance at its peak.'],
      ];
      foreach ($steps as $step): ?>
      <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:1.8rem 1.2rem">
        <div style="font-size:2rem;margin-bottom:.5rem"><?= $step[1] ?></div>
        <div style="font-size:.8rem;font-weight:700;color:var(--pl);margin-bottom:.4rem">STEP <?= $step[0] ?></div>
        <h3 style="font-size:1rem;font-weight:700;color:var(--primary);margin-bottom:.5rem"><?= $step[2] ?></h3>
        <p style="font-size:.88rem;color:var(--muted)"><?= $step[3] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SECTION: CLIENT FEEDBACK (fixed testimonials) -->
<section>
  <div class="section-inner">
    <div class="section-header">
      <div class="section-tag">Client Feedback</div>
      <h2 class="section-title">What Our Clients Say</h2>
      <p class="section-sub">Trusted by businesses across the globe to deliver AI solutions that work.</p>
    </div>
    <div class="testimonials-grid">
      <div class="testimonial">
        <div class="stars">★★★★★<span style="font-size:.78rem;color:var(--muted);margin-left:.4rem">5/5</span></div>
        <blockquote>"AI-Solutions transformed our customer support. Response times dropped by 70% and satisfaction scores hit an all-time high."</blockquote>
        <div class="testimonial-author">
          <div class="author-avatar">JM</div>
          <div class="author-info"><strong>James Mitchell</strong><span>CTO, TechForward Ltd</span></div>
        </div>
      </div>
      <div class="testimonial">
        <div class="stars">★★★★★<span style="font-size:.78rem;color:var(--muted);margin-left:.4rem">5/5</span></div>
        <blockquote>"The prototype they delivered in two weeks would have taken us six months internally. Exceptional quality and speed."</blockquote>
        <div class="testimonial-author">
          <div class="author-avatar">SP</div>
          <div class="author-info"><strong>Sarah Park</strong><span>Head of Innovation, NovaCorp</span></div>
        </div>
      </div>
      <div class="testimonial">
        <div class="stars">★★★★<span style="color:#d1d5db">★</span><span style="font-size:.78rem;color:var(--muted);margin-left:.4rem">4/5</span></div>
        <blockquote>"Their AI assistant seamlessly integrates with our existing tools and the team support throughout has been outstanding."</blockquote>
        <div class="testimonial-author">
          <div class="author-avatar">RK</div>
          <div class="author-info"><strong>Ravi Kumar</strong><span>Operations Director, GlobalEdge</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- SECTION: RECENT REVIEWS FROM DB -->
<?php
$feedback_reviews = [];
$avg_rating    = 0;
$total_reviews = 0;
$conn = @new mysqli('localhost', 'root', '', 'ai_solutions_db');
if (!$conn->connect_error) {
    $r  = $conn->query("SELECT name, company, rating, message FROM feedback ORDER BY submitted_at DESC LIMIT 3");
    if ($r) while ($row = $r->fetch_assoc()) $feedback_reviews[] = $row;
    $r2 = $conn->query("SELECT COUNT(*) as cnt, ROUND(AVG(rating),1) as avg_r FROM feedback");
    if ($r2) { $s = $r2->fetch_assoc(); $total_reviews = (int)$s['cnt']; $avg_rating = (float)$s['avg_r']; }
    $conn->close();
}
if ($total_reviews === 0) { $avg_rating = 4.7; $total_reviews = 0; }
?>
<section class="bg-light">
  <div class="section-inner">
    <div class="section-header" style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:1rem">
      <div>
        <div class="section-tag">Recent Reviews</div>
        <h2 class="section-title" style="margin-bottom:.25rem">Latest From Our Customers</h2>
        <?php if ($total_reviews > 0): ?>
        <p class="section-sub">
          <span style="color:#f59e0b">★★★★★</span>
          <strong style="color:var(--primary)"><?= $avg_rating ?>/5</strong>
          <span style="color:var(--muted)"> &mdash; <?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?></span>
        </p>
        <?php else: ?>
        <p class="section-sub">Be the first to share your experience with AI-Solutions.</p>
        <?php endif; ?>
      </div>
      <a href="feedback.php" class="btn btn-blue" style="flex-shrink:0">⭐ Leave a Review</a>
    </div>

    <?php if (empty($feedback_reviews)): ?>
    <div style="text-align:center;padding:3rem;background:var(--white);border:1px solid var(--border);border-radius:var(--radius)">
      <div style="font-size:2.5rem;margin-bottom:.75rem">💬</div>
      <p style="color:var(--muted);margin-bottom:1.5rem">No customer reviews yet. Be the first!</p>
      <a href="feedback.php" class="btn btn-blue">Leave a Review</a>
    </div>
    <?php else: ?>
    <div class="testimonials-grid">
      <?php foreach ($feedback_reviews as $rev):
        $words    = explode(' ', trim($rev['name']));
        $initials = strtoupper(substr($words[0],0,1).(isset($words[1])?substr($words[1],0,1):''));
        $stars    = (int)$rev['rating'];
      ?>
      <div class="testimonial">
        <div class="stars">
          <?= str_repeat('★', $stars) ?><span style="color:#d1d5db"><?= str_repeat('★', 5-$stars) ?></span>
          <span style="font-size:.78rem;color:var(--muted);margin-left:.4rem"><?= $stars ?>/5</span>
        </div>
        <blockquote>"<?= htmlspecialchars($rev['message']) ?>"</blockquote>
        <div class="testimonial-author">
          <div class="author-avatar"><?= htmlspecialchars($initials) ?></div>
          <div class="author-info">
            <strong><?= htmlspecialchars($rev['name']) ?></strong>
            <span><?= htmlspecialchars($rev['company'] ?: 'Customer') ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2rem">
      <a href="feedback.php" style="color:var(--pl);font-weight:600;text-decoration:none;font-size:.95rem">View all reviews &amp; leave your own →</a>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- BLOG PREVIEW -->
<?php
$blog_posts = [];
$conn2 = @new mysqli('localhost', 'root', '', 'ai_solutions_db');
if (!$conn2->connect_error) {
    $r = $conn2->query("SELECT title,slug,excerpt,category,image_emoji,created_at FROM blog_posts WHERE status='published' ORDER BY created_at DESC LIMIT 3");
    if ($r) while ($row = $r->fetch_assoc()) $blog_posts[] = $row;
    $conn2->close();
}
if (empty($blog_posts)) {
    $blog_posts = [
        ['title'=>'How AI Virtual Assistants Are Transforming Customer Support','slug'=>'ai-virtual-assistants-transforming-customer-support','excerpt'=>'Discover how AI-powered virtual assistants are helping businesses reduce response times by up to 70%.','category'=>'AI Technology','image_emoji'=>'🤖','created_at'=>'2026-05-10'],
        ['title'=>'Rapid Prototyping with AI: From Idea to Working Product in Days','slug'=>'rapid-prototyping-with-ai','excerpt'=>'Learn how AI-assisted development enables teams to go from concept to prototype in a fraction of the time.','category'=>'Product Development','image_emoji'=>'⚡','created_at'=>'2026-05-05'],
        ['title'=>'Top 5 Business Processes You Should Automate Right Now','slug'=>'top-5-business-processes-to-automate','excerpt'=>'Not sure where to start with automation? Here are five processes that deliver the highest ROI.','category'=>'Automation','image_emoji'=>'🔄','created_at'=>'2026-04-28'],
    ];
}
$cat_bg = ['AI Technology'=>'#dbeafe','Product Development'=>'#fce7f3','Automation'=>'#d1fae5','Industry Insights'=>'#fef9c3','General'=>'#e0f2fe'];
$cat_cl = ['AI Technology'=>'#1d4ed8','Product Development'=>'#9d174d','Automation'=>'#065f46','Industry Insights'=>'#854d0e','General'=>'#0369a1'];
?>
<section>
  <div class="section-inner">
    <div class="section-header" style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:1rem">
      <div>
        <div class="section-tag">Latest Articles</div>
        <h2 class="section-title">From Our Blog</h2>
        <p class="section-sub">Insights on AI, automation, and digital transformation.</p>
      </div>
      <a href="blog.php" class="btn btn-dark" style="flex-shrink:0">View All Posts →</a>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1.5rem">
      <?php foreach ($blog_posts as $bp):
        $bg = $cat_bg[$bp['category']] ?? '#e0f2fe';
        $cl = $cat_cl[$bp['category']] ?? '#0369a1';
      ?>
      <div class="card" style="padding:0;overflow:hidden">
        <div style="height:120px;background:linear-gradient(135deg,#1a3c6e,#0e7490);display:flex;align-items:center;justify-content:center;font-size:3rem">
          <?= $bp['image_emoji'] ?>
        </div>
        <div style="padding:1.4rem">
          <span style="display:inline-block;background:<?= $bg ?>;color:<?= $cl ?>;font-size:.72rem;font-weight:700;padding:.2rem .65rem;border-radius:50px;margin-bottom:.6rem"><?= htmlspecialchars($bp['category']) ?></span>
          <h3 style="font-size:1rem;font-weight:700;color:var(--primary);margin-bottom:.5rem;line-height:1.4">
            <a href="blog/post.php?slug=<?= urlencode($bp['slug']) ?>" style="text-decoration:none;color:inherit"><?= htmlspecialchars($bp['title']) ?></a>
          </h3>
          <p style="color:var(--muted);font-size:.88rem;line-height:1.6;margin-bottom:1rem"><?= htmlspecialchars(mb_strimwidth($bp['excerpt'],0,100,'…')) ?></p>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:.78rem;color:var(--muted)"><?= date('M j, Y', strtotime($bp['created_at'])) ?></span>
            <a href="blog/post.php?slug=<?= urlencode($bp['slug']) ?>" style="color:var(--pl);font-weight:600;font-size:.85rem;text-decoration:none">Read →</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA BANNER -->
<div class="cta-banner">
  <h2>Ready to Transform Your Business with AI?</h2>
  <p>Join 500+ companies already benefiting from AI-Solutions' intelligent software.</p>
  <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
    <a href="contact.php" class="btn btn-primary" style="background:#fff;color:var(--primary)">📅 Schedule a Demo</a>
    <a href="gallery.php" class="btn btn-outline">View Our Work</a>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>

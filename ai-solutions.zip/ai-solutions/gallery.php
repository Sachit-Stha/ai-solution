<?php
$pageTitle = "Gallery – AI-Solutions";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/nav.php'; ?>

<div class="page-hero">
  <div class="breadcrumb"><a href="index.php">Home</a> / Gallery</div>
  <h1>Events &amp; Highlights</h1>
  <p>A snapshot of our product demonstrations, promotional events, and industry partnerships.</p>
</div>

<section>
  <div class="section-inner">

    <!-- FILTER -->
    <div class="gallery-filter">
      <button class="filter-btn active" data-cat="all">All</button>
      <button class="filter-btn" data-cat="events">Events</button>
      <button class="filter-btn" data-cat="demo">Demonstrations</button>
      <button class="filter-btn" data-cat="team">Team</button>
      <button class="filter-btn" data-cat="awards">Awards</button>
    </div>

    <!-- GALLERY GRID -->
    <div class="gallery-grid">
      <?php
      $items = [
        ['🎤','AI Summit 2025 – Keynote','events','Our CEO presenting the future of AI-assisted work at the annual AI Summit, Sunderland.'],
        ['🤖','Virtual Assistant Live Demo','demo','Live demonstration of our AI chatbot handling 50+ simultaneous customer queries.'],
        ['🏆','Tech Innovation Award','awards','AI-Solutions wins Best AI Product at the Northern Tech Awards 2024.'],
        ['👥','Team Hackathon','team','48-hour internal hackathon producing 12 new AI prototypes.'],
        ['🎯','Client Workshop – NovaCorp','demo','On-site design thinking workshop with NovaCorp to map automation opportunities.'],
        ['🌍','Global Expansion Launch','events','Launch event celebrating our expansion into the APAC market.'],
        ['📊','Data Analytics Showcase','demo','Showcasing real-time analytics dashboards at the Digital Business Expo.'],
        ['🤝','Partnership Signing – TechForward','events','Strategic partnership ceremony with TechForward Ltd, London.'],
        ['🎓','Graduate Recruitment Day','team','Engaging with top talent at the University of Sunderland careers fair.'],
        ['🚀','Product Launch – Aria v2','events','Launch of Aria v2, our most advanced virtual assistant to date.'],
        ['📸','Behind the Scenes','team','A look inside the AI-Solutions development lab.'],
        ['🏅','ISO 27001 Certification','awards','Achieving ISO 27001 certification – our commitment to information security.'],
      ];
      foreach ($items as $i => $item): ?>
      <div class="gallery-item" data-cat="<?= $item[2] ?>" title="<?= htmlspecialchars($item[3]) ?>">
        <div class="gi-icon"><?= $item[0] ?></div>
        <div class="gi-label"><?= htmlspecialchars($item[1]) ?></div>
        <div class="gallery-overlay">
          <div style="font-size:1.5rem"><?= $item[0] ?></div>
          <span><?= htmlspecialchars($item[1]) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- UPCOMING EVENTS -->
    <div style="margin-top:4rem">
      <div class="section-tag">What's Next</div>
      <h2 class="section-title">Upcoming Events</h2>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem;margin-top:1.5rem">
        <?php
        $events = [
          ['🗓️','June 2026','AI-Solutions Webinar: Automating Customer Service at Scale','Online – Zoom','Register your interest via the Contact page.'],
          ['🗓️','July 2026','Northern Digital Summit 2026','Newcastle, UK','AI-Solutions will be exhibiting and presenting a keynote.'],
          ['🗓️','September 2026','Product Showcase – Aria v3 Launch','Sunderland HQ','Join us for the unveiling of our next-generation assistant.'],
        ];
        foreach ($events as $ev): ?>
        <div class="card">
          <div style="font-size:1.5rem;margin-bottom:.5rem"><?= $ev[0] ?></div>
          <div style="font-size:.8rem;font-weight:700;color:var(--ad);margin-bottom:.4rem"><?= $ev[1] ?></div>
          <h3><?= htmlspecialchars($ev[2]) ?></h3>
          <p style="margin:.4rem 0;font-size:.85rem;color:var(--pl);font-weight:600">📍 <?= $ev[3] ?></p>
          <p><?= htmlspecialchars($ev[4]) ?></p>
          <br><a href="contact.php" style="color:var(--pl);font-weight:600;font-size:.88rem;text-decoration:none">Register interest →</a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</section>

<?php include 'includes/footer.php'; ?>
</body>
</html>

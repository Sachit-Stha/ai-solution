<?php
// api/config.php – shared DB config and JSON response helper

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

// Always respond as JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

function db(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        json_error('Database connection failed: ' . $conn->connect_error, 500);
    }
    return $conn;
}

function json_ok(array $data = [], string $message = 'Success'): void {
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}

function json_error(string $message, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $message, 'data' => []]);
    exit;
}

function require_admin(): void {
    session_start();
    if (empty($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
        json_error('Unauthorised', 401);
    }
}

function get_body(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? $_POST;
}

<?php
// api/feedback.php
// GET  → fetch all reviews + stats
// POST → submit new review
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $conn  = db();
    $reviews = [];
    $r = $conn->query("SELECT name,company,rating,message,submitted_at FROM feedback ORDER BY submitted_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $reviews[] = $row;

    $stats = ['total'=>0,'average'=>0,'five_star'=>0];
    $r2 = $conn->query("SELECT COUNT(*) as cnt, ROUND(AVG(rating),1) as avg_r, SUM(rating=5) as five FROM feedback");
    if ($r2) {
        $s = $r2->fetch_assoc();
        $stats = ['total'=>(int)$s['cnt'], 'average'=>(float)$s['avg_r'], 'five_star'=>(int)$s['five']];
    }
    $conn->close();
    json_ok(['reviews' => $reviews, 'stats' => $stats]);

} elseif ($method === 'POST') {
    $body    = get_body();
    $name    = trim($body['name']    ?? '');
    $email   = trim($body['email']   ?? '');
    $company = trim($body['company'] ?? '');
    $rating  = (int)($body['rating'] ?? 0);
    $message = trim($body['message'] ?? '');

    if (!$name || $rating < 1 || $rating > 5 || !$message)
        json_error('Please fill in your name, a rating, and a message.');

    $conn = db();
    $stmt = $conn->prepare(
        "INSERT INTO feedback (name,email,company,rating,message,submitted_at) VALUES (?,?,?,?,?,NOW())"
    );
    $stmt->bind_param('sssis', $name,$email,$company,$rating,$message);
    if ($stmt->execute()) {
        json_ok(['id' => $conn->insert_id], 'Review submitted successfully.');
    } else {
        json_error('Failed to save review: ' . $stmt->error);
    }
    $stmt->close();
    $conn->close();

} else {
    json_error('Method not allowed', 405);
}

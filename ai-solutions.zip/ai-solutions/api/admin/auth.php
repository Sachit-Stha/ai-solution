<?php
// api/admin/auth.php
// POST ?action=login   → authenticate
// POST ?action=logout  → destroy session
// GET  ?action=check   → check if logged in
require_once '../config.php';
session_start();

$action = $_GET['action'] ?? $_POST['action'] ?? 'check';
$body   = get_body();

if ($action === 'check') {
    if (!empty($_SESSION['admin_logged_in'])) {
        json_ok(['user' => $_SESSION['admin_user']], 'Authenticated');
    } else {
        json_error('Not authenticated', 401);
    }

} elseif ($action === 'login') {
    $username = trim($body['username'] ?? '');
    $password = trim($body['password'] ?? '');

    if (!$username || !$password) json_error('Username and password are required.');

    // Demo credentials
    if ($username === 'admin' && $password === 'Admin@1234') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user']      = $username;
        json_ok(['user' => $username], 'Login successful.');
    }

    // Try DB
    $conn = db();
    $stmt = $conn->prepare("SELECT password_hash FROM admin_users WHERE username=? LIMIT 1");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();

    if ($row && password_verify($password, $row['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user']      = $username;
        json_ok(['user' => $username], 'Login successful.');
    }

    json_error('Invalid username or password.', 401);

} elseif ($action === 'logout') {
    session_destroy();
    json_ok([], 'Logged out.');

} else {
    json_error('Unknown action.');
}

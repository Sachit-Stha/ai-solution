<?php
// api/admin/blog.php
// GET               → list all posts + stats
// GET  ?id=X        → single post
// POST action=save  → create/update post
// POST action=delete&id=X → delete
// POST action=toggle&id=X → toggle status
require_once '../config.php';
require_admin();

$method = $_SERVER['REQUEST_METHOD'];
$conn   = db();

if ($method === 'GET') {
    if (isset($_GET['id'])) {
        $id   = (int)$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id=? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $post = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $conn->close();
        if (!$post) json_error('Post not found.', 404);
        json_ok(['post' => $post]);
    } else {
        $posts = [];
        $r     = $conn->query("SELECT id,title,category,author,status,created_at FROM blog_posts ORDER BY created_at DESC");
        if ($r) while ($row = $r->fetch_assoc()) $posts[] = $row;

        $total     = count($posts);
        $published = count(array_filter($posts, fn($p) => $p['status']==='published'));
        $conn->close();
        json_ok(['posts'=>$posts,'stats'=>['total'=>$total,'published'=>$published,'drafts'=>$total-$published]]);
    }

} elseif ($method === 'POST') {
    $body   = get_body();
    $action = $body['action'] ?? 'save';

    if ($action === 'delete') {
        $id   = (int)($body['id'] ?? 0);
        if (!$id) json_error('ID is required.');
        $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_ok([], 'Post deleted.');

    } elseif ($action === 'toggle') {
        $id   = (int)($body['id'] ?? 0);
        if (!$id) json_error('ID is required.');
        $stmt = $conn->prepare("UPDATE blog_posts SET status=IF(status='published','draft','published') WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_ok([], 'Status toggled.');

    } elseif ($action === 'save') {
        $id      = (int)($body['id'] ?? 0);
        $title   = trim($body['title']       ?? '');
        $slug    = trim($body['slug']        ?? '');
        $excerpt = trim($body['excerpt']     ?? '');
        $content = trim($body['content']     ?? '');
        $cat     = trim($body['category']    ?? 'General');
        $author  = trim($body['author']      ?? 'AI-Solutions Team');
        $emoji   = trim($body['image_emoji'] ?? '📝');
        $status  = ($body['status'] ?? 'draft') === 'published' ? 'published' : 'draft';

        if (!$title || !$content) json_error('Title and content are required.');

        if (!$slug) {
            $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
            $slug = trim($slug, '-');
        }

        if ($id) {
            $stmt = $conn->prepare(
                "UPDATE blog_posts SET title=?,slug=?,excerpt=?,content=?,category=?,author=?,image_emoji=?,status=?,updated_at=NOW() WHERE id=?"
            );
            $stmt->bind_param('ssssssssi', $title,$slug,$excerpt,$content,$cat,$author,$emoji,$status,$id);
        } else {
            $stmt = $conn->prepare(
                "INSERT INTO blog_posts (title,slug,excerpt,content,category,author,image_emoji,status,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())"
            );
            $stmt->bind_param('ssssssss', $title,$slug,$excerpt,$content,$cat,$author,$emoji,$status);
        }

        if ($stmt->execute()) {
            $new_id = $id ?: $conn->insert_id;
            $stmt->close();
            $conn->close();
            json_ok(['id' => $new_id], 'Post saved successfully.');
        } else {
            json_error('Save failed: ' . $stmt->error);
        }
    } else {
        json_error('Unknown action.');
    }
} else {
    json_error('Method not allowed', 405);
}

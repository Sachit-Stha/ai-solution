<?php
// api/admin/enquiries.php
// GET               → list all enquiries
// GET  ?id=X        → single enquiry (marks as read)
// POST ?action=delete&id=X → delete
require_once '../config.php';
require_admin();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';
$conn   = db();

if ($method === 'GET') {
    if (isset($_GET['id'])) {
        // Single enquiry
        $id   = (int)$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM enquiries WHERE id=? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $item = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$item) json_error('Enquiry not found.', 404);

        // Mark as read
        $upd = $conn->prepare("UPDATE enquiries SET status='read' WHERE id=?");
        $upd->bind_param('i', $id);
        $upd->execute();
        $upd->close();
        $conn->close();
        json_ok(['enquiry' => $item]);
    } else {
        // List all
        $enquiries = [];
        $r = $conn->query("SELECT * FROM enquiries ORDER BY submitted_at DESC");
        if ($r) while ($row = $r->fetch_assoc()) $enquiries[] = $row;

        // Stats
        $stats = [];
        $r2 = $conn->query("SELECT COUNT(*) as total, SUM(status='new') as new_count, COUNT(DISTINCT country) as countries FROM enquiries");
        if ($r2) $stats = $r2->fetch_assoc();
        $conn->close();
        json_ok(['enquiries' => $enquiries, 'stats' => $stats]);
    }

} elseif ($method === 'POST') {
    $body = get_body();
    $act  = $body['action'] ?? $action;
    $id   = (int)($body['id'] ?? $_GET['id'] ?? 0);

    if ($act === 'delete') {
        if (!$id) json_error('ID is required.');
        $stmt = $conn->prepare("DELETE FROM enquiries WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_ok([], 'Enquiry deleted.');

    } elseif ($act === 'mark_read') {
        if (!$id) json_error('ID is required.');
        $stmt = $conn->prepare("UPDATE enquiries SET status='read' WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_ok([], 'Marked as read.');

    } else {
        json_error('Unknown action.');
    }
} else {
    json_error('Method not allowed', 405);
}

<?php
// api/admin/feedback.php
// GET              → list all feedback + stats
// POST action=delete&id=X → delete
require_once '../config.php';
require_admin();

$method = $_SERVER['REQUEST_METHOD'];
$conn   = db();

if ($method === 'GET') {
    $all = [];
    $r   = $conn->query("SELECT * FROM feedback ORDER BY submitted_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $all[] = $row;

    $stats = ['total'=>0,'average'=>0,'five_star'=>0];
    $r2    = $conn->query("SELECT COUNT(*) as cnt, ROUND(AVG(rating),1) as avg_r, SUM(rating=5) as five FROM feedback");
    if ($r2) {
        $s     = $r2->fetch_assoc();
        $stats = ['total'=>(int)$s['cnt'],'average'=>(float)$s['avg_r'],'five_star'=>(int)$s['five']];
    }
    $conn->close();
    json_ok(['feedback' => $all, 'stats' => $stats]);

} elseif ($method === 'POST') {
    $body = get_body();
    $id   = (int)($body['id'] ?? 0);
    if (!$id) json_error('ID is required.');

    $stmt = $conn->prepare("DELETE FROM feedback WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    json_ok([], 'Feedback deleted.');

} else {
    json_error('Method not allowed', 405);
}

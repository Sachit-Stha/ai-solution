<?php
// api/contact.php
// POST → submit enquiry, returns JSON
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_error('Method not allowed', 405);

$body = get_body();

$name       = trim($body['name']        ?? '');
$email      = trim($body['email']       ?? '');
$phone      = trim($body['phone']       ?? '');
$company    = trim($body['company']     ?? '');
$country    = trim($body['country']     ?? '');
$job_title  = trim($body['job_title']   ?? '');
$job_details= trim($body['job_details'] ?? '');
$interest   = trim($body['interest']    ?? '');

// Validate
if (!$name || !$email || !$phone || !$company || !$country || !$job_details)
    json_error('Please fill in all required fields.');

if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    json_error('Please enter a valid email address.');

$conn = db();
$stmt = $conn->prepare(
    "INSERT INTO enquiries (name,email,phone,company,country,job_title,job_details,interest,submitted_at)
     VALUES (?,?,?,?,?,?,?,?,NOW())"
);
$stmt->bind_param('ssssssss', $name,$email,$phone,$company,$country,$job_title,$job_details,$interest);

if ($stmt->execute()) {
    json_ok(['id' => $conn->insert_id], 'Enquiry submitted successfully.');
} else {
    json_error('Failed to save enquiry: ' . $stmt->error);
}

$stmt->close();
$conn->close();

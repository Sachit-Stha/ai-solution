<?php
// api/blog.php
// GET ?action=list[&cat=X]  → list published posts
// GET ?action=post&slug=X   → single post + related
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') json_error('Method not allowed', 405);

$action = $_GET['action'] ?? 'list';
$conn   = db();

if ($action === 'list') {
    $cat    = trim($_GET['cat'] ?? '');
    $posts  = [];
    $cats   = [];

    $r = $conn->query("SELECT DISTINCT category FROM blog_posts WHERE status='published' ORDER BY category");
    if ($r) while ($row = $r->fetch_assoc()) $cats[] = $row['category'];

    if ($cat) {
        $stmt = $conn->prepare(
            "SELECT id,title,slug,excerpt,category,author,image_emoji,created_at
             FROM blog_posts WHERE status='published' AND category=? ORDER BY created_at DESC"
        );
        $stmt->bind_param('s', $cat);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query(
            "SELECT id,title,slug,excerpt,category,author,image_emoji,created_at
             FROM blog_posts WHERE status='published' ORDER BY created_at DESC"
        );
    }
    if ($result) while ($row = $result->fetch_assoc()) $posts[] = $row;
    $conn->close();
    json_ok(['posts' => $posts, 'categories' => $cats]);

} elseif ($action === 'post') {
    $slug = trim($_GET['slug'] ?? '');
    if (!$slug) json_error('Slug is required.');

    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE slug=? AND status='published' LIMIT 1");
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $post = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$post) json_error('Post not found.', 404);

    $related = [];
    $stmt2 = $conn->prepare(
        "SELECT id,title,slug,category,image_emoji,created_at FROM blog_posts
         WHERE status='published' AND id!=? ORDER BY created_at DESC LIMIT 3"
    );
    $stmt2->bind_param('i', $post['id']);
    $stmt2->execute();
    $r = $stmt2->get_result();
    while ($row = $r->fetch_assoc()) $related[] = $row;
    $stmt2->close();
    $conn->close();

    json_ok(['post' => $post, 'related' => $related]);

} else {
    json_error('Unknown action.');
}

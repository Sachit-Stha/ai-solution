-- AI-Solutions Database Setup
CREATE DATABASE IF NOT EXISTS ai_solutions_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ai_solutions_db;

-- ENQUIRIES TABLE
CREATE TABLE IF NOT EXISTS enquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    company VARCHAR(150) NOT NULL,
    country VARCHAR(100) NOT NULL,
    job_title VARCHAR(100),
    interest VARCHAR(50),
    job_details TEXT NOT NULL,
    status ENUM('new','read') DEFAULT 'new',
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- FEEDBACK TABLE
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150),
    company VARCHAR(150),
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    message TEXT,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ADMIN USERS TABLE
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin user: username=admin, password=Admin@1234
INSERT INTO admin_users (username, password_hash)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi')
ON DUPLICATE KEY UPDATE username=username;

-- SAMPLE ENQUIRIES DATA
INSERT INTO enquiries (name, email, phone, company, country, job_title, interest, job_details, status, submitted_at) VALUES
('Priya Sharma',    'priya@techcorp.in',        '+91 98765 43210', 'TechCorp India',    'India',          'CTO',                    'virtual_assistant', 'We need an AI assistant to handle 5,000+ daily customer queries across our e-commerce platform.', 'new',  '2026-05-18 14:22:00'),
('James Wilson',    'james@brightpath.co.uk',   '+44 7911 123456', 'BrightPath UK',     'United Kingdom', 'Head of Digital',        'demo',              'Interested in scheduling a demo to evaluate the virtual assistant for our HR department.',         'read', '2026-05-17 09:45:00'),
('Li Wei',          'liwei@horizontech.sg',     '+65 9123 4567',   'Horizon Tech',      'Singapore',      'Product Manager',        'prototyping',       'Need a rapid prototype for a new internal tool to automate expense reporting.',                    'read', '2026-05-16 16:30:00'),
('Maria Santos',    'maria@novagroup.us',        '+1 555 987 6543', 'NovaGroup',         'United States',  'Director of Operations', 'analytics',         'Looking for an analytics solution to consolidate our sales data from 5 different systems.',         'read', '2026-05-15 11:10:00'),
('Ahmed Al-Rashid', 'ahmed@gulfsolutions.ae',   '+971 50 123 456', 'Gulf Solutions',    'UAE',            'CEO',                    'automation',        'Want to automate our invoice processing and procurement workflows.',                             'new',  '2026-05-14 08:55:00'),
('Sophie Martin',   'sophie@innovatefr.fr',     '+33 6 12 34 56',  'Innovate France',   'France',         'Innovation Lead',        'virtual_assistant', 'Exploring AI chatbots for our internal IT helpdesk.',                                           'read', '2026-05-13 15:20:00');

-- SAMPLE FEEDBACK DATA
INSERT INTO feedback (name, email, company, rating, message, submitted_at) VALUES
('Priya Sharma',    'priya@techcorp.in',       'TechCorp India',   5, 'The virtual assistant exceeded our expectations. Response times are incredible.',          '2026-05-18'),
('James Wilson',    'james@brightpath.co.uk',  'BrightPath UK',    5, 'Outstanding service from start to finish. Delivered on time and on budget.',              '2026-05-17'),
('Li Wei',          'liwei@horizontech.sg',    'Horizon Tech',     4, 'Very impressed with the prototyping speed. Minor UX tweaks needed but overall excellent.', '2026-05-16'),
('Maria Santos',    'maria@novagroup.us',       'NovaGroup',        5, 'AI-Solutions completely transformed how we handle customer data. Highly recommended!',     '2026-05-15'),
('Ahmed Al-Rashid', 'ahmed@gulfsolutions.ae',  'Gulf Solutions',   4, 'Great product and support team. Looking forward to expanding our partnership.',           '2026-05-14'),
('Sophie Martin',   'sophie@innovatefr.fr',    'Innovate France',  3, 'Good product but onboarding documentation could be improved.',                            '2026-05-13');

-- BLOG POSTS TABLE
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    excerpt TEXT,
    content LONGTEXT NOT NULL,
    category VARCHAR(100) DEFAULT 'General',
    author VARCHAR(100) DEFAULT 'AI-Solutions Team',
    image_emoji VARCHAR(10) DEFAULT '📝',
    status ENUM('published','draft') DEFAULT 'draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO blog_posts (title,slug,excerpt,content,category,author,image_emoji,status,created_at) VALUES
('How AI Virtual Assistants Are Transforming Customer Support','ai-virtual-assistants-transforming-customer-support','Discover how AI-powered virtual assistants are helping businesses reduce response times by up to 70%.','<p>The landscape of customer support has changed dramatically. AI-powered virtual assistants now handle thousands of simultaneous conversations 24/7.</p><h2>The Problem with Traditional Support</h2><p>Traditional support relies on human agents available only during business hours, creating frustration and long queues.</p><h2>How AI Assistants Change Everything</h2><p>AI assistants like Aria understand natural language, remember context, and resolve most queries without human intervention. When queries are too complex, they seamlessly hand off to a human agent.</p><h2>Real Results</h2><p>Our clients report response time reductions of up to 70%. One enterprise client now resolves over 80% of all incoming queries autonomously.</p><h2>Getting Started</h2><p>AI-Solutions offers a streamlined onboarding process that gets most clients up and running within two weeks. Contact us today to schedule a demo.</p>','AI Technology','AI-Solutions Team','🤖','published','2026-05-10 09:00:00'),
('Rapid Prototyping with AI: From Idea to Working Product in Days','rapid-prototyping-with-ai','Learn how AI-assisted development enables teams to go from concept to working prototype in a fraction of the time.','<p>In today\'s competitive market, speed is everything. The ability to rapidly validate ideas can be the difference between leading the market and playing catch-up.</p><h2>What Is AI-Assisted Prototyping?</h2><p>AI-assisted prototyping combines your team\'s expertise with the speed of artificial intelligence. AI tools can generate code scaffolding, suggest architecture patterns, and produce initial UI designs.</p><h2>Our Approach</h2><p>At AI-Solutions, we deliver working products within five to ten business days using a proven methodology: discovery workshop, AI-generated architecture, iterative development sprints, and daily client check-ins.</p><h2>Case Study</h2><p>A mid-sized logistics company needed an internal expense reporting tool. Using our approach, we delivered a fully functional prototype in six business days. The traditional estimate had been three months.</p>','Product Development','AI-Solutions Team','⚡','published','2026-05-05 10:30:00'),
('Top 5 Business Processes You Should Automate Right Now','top-5-business-processes-to-automate','Not sure where to start with automation? Here are the five processes that deliver the highest ROI.','<p>Business process automation has moved from a luxury to a necessity. Companies that automate effectively operate leaner and faster.</p><h2>1. Invoice Processing</h2><p>AI-powered document processing can extract data from invoices, validate it against purchase orders, and route for approval without human intervention.</p><h2>2. Customer Onboarding</h2><p>Automation can handle document collection, identity verification, welcome emails, and account setup — getting new customers productive faster.</p><h2>3. IT Helpdesk Ticketing</h2><p>An AI assistant can resolve the most common IT issues automatically, cutting helpdesk costs by up to 40%.</p><h2>4. HR Leave Management</h2><p>Automated workflows handle the entire leave process — from request to approval to calendar update — in seconds.</p><h2>5. Sales Reporting</h2><p>Automated pipelines can aggregate data, generate visualisations, and distribute reports to stakeholders automatically.</p>','Automation','AI-Solutions Team','🔄','published','2026-04-28 14:00:00'),
('Understanding AI Ethics in Enterprise Software','understanding-ai-ethics-enterprise-software','As AI becomes embedded in enterprise workflows, understanding the ethical implications is more important than ever.','<p>Artificial intelligence is embedded in the products and processes that power modern enterprises. With that comes significant responsibility.</p><h2>Why Ethics Matter in AI</h2><p>AI systems learn from data, and data reflects the world as it is — including its biases and imperfections. Without careful design, AI systems can inadvertently amplify these problems.</p><h2>Key Principles We Follow</h2><p>Every product we build is guided by transparency, fairness, accountability, and privacy by design. We document our AI decisions, audit for bias regularly, and ensure humans remain in control of high-stakes decisions.</p><h2>The Business Case</h2><p>Ethical AI is also good business. Companies transparent about their AI use build greater trust with customers and face fewer regulatory risks.</p>','Industry Insights','AI-Solutions Team','🧠','published','2026-04-15 11:00:00');

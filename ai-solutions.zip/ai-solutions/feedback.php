<?php
// FRONTEND: feedback.php
// Backend logic is separated into backend/feedback_backend.php
require_once 'backend/feedback_backend.php';
$pageTitle = "Leave Feedback – AI-Solutions";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
<style>
.star-rating{display:flex;flex-direction:row-reverse;justify-content:flex-end;gap:.3rem;margin-top:.4rem}
.star-rating input{display:none}
.star-rating label{font-size:2.2rem;color:#d1d5db;cursor:pointer;transition:color .15s;line-height:1}
.star-rating input:checked~label,.star-rating label:hover,.star-rating label:hover~label{color:#f59e0b}
.rating-text{font-size:.88rem;color:var(--muted);margin-top:.4rem;min-height:1.2rem}
.review-card{background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:1.2rem}
.review-stars{color:#f59e0b;font-size:1rem;margin-bottom:.4rem}
.review-card blockquote{font-style:italic;color:var(--muted);font-size:.88rem;line-height:1.6;margin-bottom:.6rem}
.review-author{display:flex;align-items:center;gap:.6rem}
.review-avatar{width:34px;height:34px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;flex-shrink:0}
.review-info strong{display:block;font-size:.85rem;color:var(--text)}
.review-info span{font-size:.75rem;color:var(--muted)}
</style>
</head>
<body>
<?php include 'includes/nav.php'; ?>

<div class="page-hero">
  <div class="breadcrumb"><a href="index.php">Home</a> / Feedback</div>
  <h1>Share Your Experience</h1>
  <p>Your feedback helps us improve and lets others know what to expect from AI-Solutions.</p>
</div>

<section>
  <div class="section-inner">
    <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:3rem;align-items:start">

      <!-- FORM -->
      <div class="form-card">
        <?php if ($success): ?>
        <div style="text-align:center;padding:3rem 2rem">
          <div style="font-size:4rem;margin-bottom:1rem">🎉</div>
          <h2 style="font-size:1.6rem;font-weight:800;color:var(--primary);margin-bottom:.75rem">Thank You!</h2>
          <p style="color:var(--muted);margin-bottom:2rem">Your feedback has been saved successfully. We really appreciate you taking the time.</p>
          <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
            <a href="feedback.php" class="btn btn-blue">Leave Another Review</a>
            <a href="index.php" class="btn" style="color:var(--primary);border:2px solid var(--border);background:var(--white)">Back to Home</a>
          </div>
        </div>
        <?php else: ?>
        <h2 style="font-size:1.4rem;font-weight:800;color:var(--primary);margin-bottom:.25rem">Write a Review</h2>
        <p style="color:var(--muted);font-size:.9rem;margin-bottom:1.5rem">Fields marked <span style="color:#dc2626">*</span> are required.</p>
        <?php if ($error): ?>
        <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST" action="feedback.php">
          <div class="form-row">
            <div class="form-group">
              <label for="name">Your Name <span style="color:#dc2626">*</span></label>
              <input type="text" id="name" name="name" placeholder="e.g. John Smith" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" id="email" name="email" placeholder="john@company.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label for="company">Company Name</label>
            <input type="text" id="company" name="company" placeholder="Your Company Ltd" value="<?= htmlspecialchars($_POST['company'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Your Rating <span style="color:#dc2626">*</span></label>
            <div class="star-rating">
              <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= (($_POST['rating'] ?? 0) == $i) ? 'checked' : '' ?>>
              <label for="star<?= $i ?>" title="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>">&#9733;</label>
              <?php endfor; ?>
            </div>
            <div class="rating-text" id="ratingText">Click a star to rate</div>
          </div>
          <div class="form-group">
            <label for="message">Your Review <span style="color:#dc2626">*</span></label>
            <textarea id="message" name="message" placeholder="Tell us about your experience..." required style="min-height:140px"><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="submit-btn">&#11088; Submit Review</button>
        </form>
        <?php endif; ?>
      </div>

      <!-- SIDEBAR -->
      <div>
        <!-- STATS -->
        <div style="background:var(--primary);color:#fff;border-radius:var(--radius);padding:1.5rem;margin-bottom:1.5rem;text-align:center">
          <div style="font-size:3.5rem;font-weight:800;line-height:1"><?= $avg_rating ?></div>
          <div style="color:#f59e0b;font-size:1.4rem;margin:.3rem 0">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <div style="opacity:.8;font-size:.9rem">Based on <?= $total_reviews ?> reviews</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-top:1.2rem">
            <div style="background:rgba(255,255,255,.1);border-radius:8px;padding:.75rem">
              <div style="font-size:1.4rem;font-weight:700"><?= $total_reviews > 0 ? round(count(array_filter($recent_reviews, fn($r) => $r['rating']==5)) / $total_reviews * 100) : 87 ?>%</div>
              <div style="font-size:.75rem;opacity:.75">5-star reviews</div>
            </div>
            <div style="background:rgba(255,255,255,.1);border-radius:8px;padding:.75rem">
              <div style="font-size:1.4rem;font-weight:700">98%</div>
              <div style="font-size:.75rem;opacity:.75">Would recommend</div>
            </div>
          </div>
        </div>

        <!-- ALL REVIEWS -->
        <h3 style="font-size:1rem;font-weight:700;color:var(--primary);margin-bottom:1rem">
          All Reviews
          <span style="background:#e0f2fe;color:var(--pl);font-size:.75rem;font-weight:700;padding:.2rem .6rem;border-radius:50px;margin-left:.4rem"><?= count($recent_reviews) ?></span>
        </h3>
        <?php if (empty($recent_reviews)): ?>
        <div style="text-align:center;padding:2rem;background:var(--bg);border-radius:var(--radius);border:1px solid var(--border)">
          <p style="color:var(--muted);font-size:.9rem">No reviews yet. Be the first!</p>
        </div>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:1rem;max-height:600px;overflow-y:auto;padding-right:.3rem">
          <?php foreach ($recent_reviews as $rev):
            $words = explode(' ', trim($rev['name']));
            $initials = strtoupper(substr($words[0],0,1).(isset($words[1])?substr($words[1],0,1):''));
          ?>
          <div class="review-card">
            <div class="review-stars">
              <?= str_repeat('&#9733;',(int)$rev['rating']) ?>
              <span style="color:#d1d5db"><?= str_repeat('&#9733;',5-(int)$rev['rating']) ?></span>
              <span style="font-size:.75rem;color:var(--muted);margin-left:.3rem"><?= $rev['rating'] ?>/5</span>
            </div>
            <blockquote>"<?= htmlspecialchars($rev['message']) ?>"</blockquote>
            <div class="review-author">
              <div class="review-avatar"><?= htmlspecialchars($initials) ?></div>
              <div class="review-info">
                <strong><?= htmlspecialchars($rev['name']) ?></strong>
                <span><?= htmlspecialchars($rev['company'] ?: 'Customer') ?></span>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
<script>
const labels = ['','Terrible','Poor','Average','Good','Excellent'];
document.querySelectorAll('.star-rating input').forEach(input => {
  input.addEventListener('change', () => {
    document.getElementById('ratingText').textContent = labels[input.value] + ' – ' + input.value + '/5 stars';
  });
});
</script>
</body>
</html>

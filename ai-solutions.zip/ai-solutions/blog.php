<?php
// FRONTEND: blog.php
// Backend logic is separated into backend/blog_backend.php
require_once 'backend/blog_backend.php';
$pageTitle = "Blog – AI-Solutions";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
<style>
.blog-card{background:var(--white);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:box-shadow .2s,transform .2s;display:flex;flex-direction:column}
.blog-card:hover{box-shadow:var(--shadowlg);transform:translateY(-4px)}
.blog-card-thumb{height:180px;display:flex;align-items:center;justify-content:center;font-size:4rem;background:linear-gradient(135deg,#e0f2fe,#bae6fd)}
.blog-card-body{padding:1.5rem;flex:1;display:flex;flex-direction:column}
.blog-cat-badge{display:inline-block;font-size:.75rem;font-weight:700;padding:.25rem .75rem;border-radius:50px;margin-bottom:.75rem}
.blog-card h3{font-size:1.05rem;font-weight:700;color:var(--primary);margin-bottom:.6rem;line-height:1.4}
.blog-card h3 a{text-decoration:none;color:inherit}
.blog-card h3 a:hover{color:var(--pl)}
.blog-card p{color:var(--muted);font-size:.9rem;line-height:1.6;flex:1}
.blog-meta{display:flex;align-items:center;gap:.75rem;margin-top:1rem;font-size:.8rem;color:var(--muted)}
.blog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem}
.filter-bar{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:2rem}
.filter-bar a{padding:.4rem 1rem;border-radius:50px;border:1.5px solid var(--border);background:var(--white);color:var(--muted);font-size:.85rem;text-decoration:none;transition:.2s}
.filter-bar a:hover,.filter-bar a.active{background:var(--primary);color:#fff;border-color:var(--primary)}
.featured-post{display:grid;grid-template-columns:1fr 1.2fr;gap:0;background:var(--white);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:2rem}
.featured-thumb{background:linear-gradient(135deg,#1a3c6e,#0e7490);display:flex;align-items:center;justify-content:center;font-size:6rem;min-height:280px}
.featured-body{padding:2.5rem;display:flex;flex-direction:column;justify-content:center}
.featured-body h2{font-size:1.5rem;font-weight:800;color:var(--primary);margin-bottom:.75rem;line-height:1.3}
.featured-body h2 a{text-decoration:none;color:inherit}
.featured-body h2 a:hover{color:var(--pl)}
.featured-body p{color:var(--muted);line-height:1.7;margin-bottom:1.2rem}
@media(max-width:768px){.featured-post{grid-template-columns:1fr}.featured-thumb{min-height:160px;font-size:4rem}}
</style>
</head>
<body>
<?php include 'includes/nav.php'; ?>

<div class="page-hero">
  <div class="breadcrumb"><a href="index.php">Home</a> / Blog</div>
  <h1>AI-Solutions Blog</h1>
  <p>Insights, updates, and practical guides on AI, automation, and digital transformation.</p>
</div>

<section>
  <div class="section-inner">

    <?php if (!empty($db_posts)): $featured = $db_posts[0]; ?>
    <div class="featured-post">
      <div class="featured-thumb"><?= $featured['image_emoji'] ?></div>
      <div class="featured-body">
        <span class="blog-cat-badge" style="<?= catStyle($featured['category'],$cat_colors) ?>;width:fit-content"><?= htmlspecialchars($featured['category']) ?></span>
        <h2><a href="blog/post.php?slug=<?= urlencode($featured['slug']) ?>"><?= htmlspecialchars($featured['title']) ?></a></h2>
        <p><?= htmlspecialchars($featured['excerpt']) ?></p>
        <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
          <a href="blog/post.php?slug=<?= urlencode($featured['slug']) ?>" class="btn btn-blue" style="padding:.6rem 1.4rem;font-size:.9rem">Read Article →</a>
          <span style="font-size:.82rem;color:var(--muted)">By <?= htmlspecialchars($featured['author']) ?> &bull; <?= date('M j, Y',strtotime($featured['created_at'])) ?></span>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <div class="filter-bar">
      <a href="blog.php" class="<?= !$selected_cat ? 'active' : '' ?>">All Posts</a>
      <?php foreach ($categories as $cat): ?>
      <a href="blog.php?cat=<?= urlencode($cat) ?>" class="<?= $selected_cat===$cat ? 'active' : '' ?>"><?= htmlspecialchars($cat) ?></a>
      <?php endforeach; ?>
    </div>

    <?php $rest = array_slice($db_posts, 1); ?>
    <?php if (empty($rest)): ?>
    <div style="text-align:center;padding:3rem;background:var(--white);border:1px solid var(--border);border-radius:var(--radius)">
      <p style="color:var(--muted)">No posts in this category yet.</p>
      <br><a href="blog.php" style="color:var(--pl);font-weight:600;text-decoration:none">View all posts →</a>
    </div>
    <?php else: ?>
    <div class="blog-grid">
      <?php foreach ($rest as $post): ?>
      <div class="blog-card">
        <div class="blog-card-thumb"><?= $post['image_emoji'] ?></div>
        <div class="blog-card-body">
          <span class="blog-cat-badge" style="<?= catStyle($post['category'],$cat_colors) ?>"><?= htmlspecialchars($post['category']) ?></span>
          <h3><a href="blog/post.php?slug=<?= urlencode($post['slug']) ?>"><?= htmlspecialchars($post['title']) ?></a></h3>
          <p><?= htmlspecialchars($post['excerpt']) ?></p>
          <div class="blog-meta">
            <strong><?= htmlspecialchars($post['author']) ?></strong>
            <span>&bull;</span>
            <span><?= date('M j, Y',strtotime($post['created_at'])) ?></span>
          </div>
          <br>
          <a href="blog/post.php?slug=<?= urlencode($post['slug']) ?>" style="color:var(--pl);font-weight:600;font-size:.88rem;text-decoration:none">Read more →</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

  </div>
</section>

<?php include 'includes/footer.php'; ?>
</body>
</html>

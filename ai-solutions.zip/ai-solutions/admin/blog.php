<?php
// FRONTEND: admin/blog.php
// Backend logic is separated into backend/admin/blog_backend.php
require_once '../backend/admin/blog_backend.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog Posts – AI-Solutions Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#f0f4f8">

<div class="admin-nav">
  <div class="brand">
    <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
    AI-Solutions Admin
  </div>
  <div class="user-info">
    👤 <?= htmlspecialchars($_SESSION['admin_user']) ?>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="menu-label">Main</div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="enquiries.php">📩 Enquiries</a>
    <a href="feedback.php">⭐ Feedback</a>
    <a href="blog.php" class="active">📝 Blog Posts</a>
    <div class="menu-label">Site</div>
    <a href="../blog.php" target="_blank">📖 View Blog</a>
    <a href="../index.php" target="_blank">🌐 View Website</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <div class="admin-main">
    <div class="admin-page-header" style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:1rem">
      <div>
        <h1>Blog Posts</h1>
        <p>Create and manage your blog articles</p>
      </div>
      <a href="blog_edit.php" class="btn btn-blue" style="padding:.6rem 1.2rem;font-size:.9rem;border-radius:8px;text-decoration:none;display:inline-flex;align-items:center;gap:.4rem">✏️ New Post</a>
    </div>

    <?php if ($alert): ?>
    <div class="alert alert-success"><?= htmlspecialchars($alert) ?></div>
    <?php endif; ?>

    <div class="stat-cards">
      <div class="stat-card"><div class="num"><?= $total ?></div><div class="lbl">📝 Total Posts</div></div>
      <div class="stat-card green"><div class="num"><?= $published ?></div><div class="lbl">✅ Published</div></div>
      <div class="stat-card amber"><div class="num"><?= $drafts ?></div><div class="lbl">📋 Drafts</div></div>
    </div>

    <div class="admin-card">
      <h2>All Posts (<?= $total ?>)</h2>
      <?php if (empty($posts)): ?>
      <div style="text-align:center;padding:3rem;color:var(--muted)">
        <div style="font-size:2.5rem;margin-bottom:.75rem">📝</div>
        <p>No blog posts yet.</p>
        <br><a href="blog_edit.php" style="color:var(--pl);font-weight:600;text-decoration:none">Create your first post →</a>
      </div>
      <?php else: ?>
      <div style="overflow-x:auto">
        <table class="data-table">
          <thead>
            <tr><th>#</th><th>Title</th><th>Category</th><th>Author</th><th>Date</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php $i=1; foreach ($posts as $p): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td style="max-width:280px"><strong style="font-size:.9rem"><?= htmlspecialchars($p['title']) ?></strong></td>
              <td><span style="font-size:.82rem;color:var(--pl)"><?= htmlspecialchars($p['category']) ?></span></td>
              <td style="font-size:.85rem"><?= htmlspecialchars($p['author']) ?></td>
              <td style="white-space:nowrap;font-size:.82rem;color:var(--muted)"><?= date('M j, Y',strtotime($p['created_at'])) ?></td>
              <td><span class="badge <?= $p['status']==='published'?'badge-read':'badge-pending' ?>"><?= ucfirst($p['status']) ?></span></td>
              <td>
                <div class="table-actions">
                  <a href="blog_edit.php?id=<?= $p['id'] ?>" class="btn-sm">Edit</a>
                  <a href="blog.php?toggle=<?= $p['id'] ?>" class="btn-sm" onclick="return confirm('Toggle status?')"><?= $p['status']==='published'?'Unpublish':'Publish' ?></a>
                  <a href="blog.php?delete=<?= $p['id'] ?>" class="btn-sm btn-danger" onclick="return confirm('Delete this post permanently?')">Delete</a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>

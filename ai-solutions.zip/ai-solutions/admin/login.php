<?php
session_start();
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

// Demo credentials (in production use DB with hashed passwords)
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'Admin@1234');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } elseif ($username === ADMIN_USER && $password === ADMIN_PASS) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $username;
        header('Location: dashboard.php');
        exit;
    } else {
        // Try DB if available
        $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn->connect_error) {
            $stmt = $conn->prepare("SELECT id, password_hash FROM admin_users WHERE username = ? LIMIT 1");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $hash);
                $stmt->fetch();
                if (password_verify($password, $hash)) {
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_user'] = $username;
                    header('Location: dashboard.php');
                    exit;
                }
            }
            $stmt->close();
            $conn->close();
        }
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login – AI-Solutions</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="admin-login-wrap">
  <div class="admin-login-card">
    <div class="admin-login-logo">
      <div class="logo-icon">AI</div>
      <h2>Admin Portal</h2>
      <p>AI-Solutions Management System</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="admin" required autocomplete="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required autocomplete="current-password">
      </div>
      <button type="submit" class="submit-btn">🔐 Login</button>
    </form>

    <div style="text-align:center;margin-top:1.5rem;font-size:.85rem;color:var(--muted)">
      <strong>Demo credentials:</strong> admin / Admin@1234<br>
      <a href="../index.php" style="color:var(--pl);text-decoration:none;margin-top:.5rem;display:inline-block">← Back to website</a>
    </div>
  </div>
</div>

</body>
</html>

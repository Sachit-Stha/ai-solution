<?php
// FRONTEND: admin/feedback.php
// Backend logic is separated into backend/admin/feedback_backend.php
require_once '../backend/admin/feedback_backend.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Feedback – AI-Solutions Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#f0f4f8">

<div class="admin-nav">
  <div class="brand">
    <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
    AI-Solutions Admin
  </div>
  <div class="user-info">
    👤 <?= htmlspecialchars($_SESSION['admin_user']) ?>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="menu-label">Main</div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="enquiries.php">📩 Enquiries</a>
    <a href="feedback.php" class="active">⭐ Feedback</a>
    <a href="blog.php">📝 Blog Posts</a>
    <div class="menu-label">Site</div>
    <a href="../blog.php" target="_blank">📖 View Blog</a>
    <a href="../index.php" target="_blank">🌐 View Website</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <div class="admin-main">
    <div class="admin-page-header">
      <h1>Customer Feedback</h1>
      <p>All ratings and reviews submitted by customers</p>
    </div>

    <?php if ($message_alert): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message_alert) ?></div>
    <?php endif; ?>

    <div class="stat-cards">
      <div class="stat-card"><div class="num"><?= $total ?></div><div class="lbl">⭐ Total Reviews</div></div>
      <div class="stat-card green"><div class="num"><?= $avg ?>/5</div><div class="lbl">📈 Average Rating</div></div>
      <div class="stat-card amber"><div class="num"><?= $five_star ?></div><div class="lbl">🌟 5-Star Reviews</div></div>
      <div class="stat-card"><div class="num"><?= $total > 0 ? round($five_star/$total*100) : 0 ?>%</div><div class="lbl">😊 Satisfaction Rate</div></div>
    </div>

    <div class="admin-card">
      <h2>All Feedback (<?= $total ?>)</h2>
      <?php if (empty($all_feedback)): ?>
      <p style="color:var(--muted);text-align:center;padding:2rem">No feedback submitted yet. <a href="../feedback.php" target="_blank">Go to feedback page →</a></p>
      <?php else: ?>
      <div style="overflow-x:auto">
        <table class="data-table">
          <thead>
            <tr><th>#</th><th>Name</th><th>Email</th><th>Company</th><th>Rating</th><th>Message</th><th>Date</th><th>Action</th></tr>
          </thead>
          <tbody>
            <?php $rowNum=1; foreach ($all_feedback as $f): ?>
            <tr>
              <td><?= $rowNum++ ?></td>
              <td><strong><?= htmlspecialchars($f['name']) ?></strong></td>
              <td style="font-size:.82rem"><?= htmlspecialchars($f['email']??'—') ?></td>
              <td><?= htmlspecialchars($f['company']??'—') ?></td>
              <td>
                <span style="color:#f59e0b"><?= str_repeat('★',(int)$f['rating']) ?></span>
                <span style="color:#d1d5db"><?= str_repeat('★',5-(int)$f['rating']) ?></span>
                <span style="font-size:.8rem;color:var(--muted);margin-left:.3rem"><?= $f['rating'] ?>/5</span>
              </td>
              <td style="max-width:300px;font-size:.87rem;color:var(--muted)"><?= htmlspecialchars(mb_strimwidth($f['message'],0,100,'...')) ?></td>
              <td style="font-size:.82rem;color:var(--muted);white-space:nowrap"><?= substr($f['submitted_at'],0,10) ?></td>
              <td><a href="feedback.php?delete=<?= $f['id'] ?>" class="btn-sm btn-danger" onclick="return confirm('Delete this feedback permanently?')">Delete</a></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <div class="admin-card">
      <h2>Rating Distribution</h2>
      <?php for ($stars=5; $stars>=1; $stars--):
        $count = count(array_filter($all_feedback, function($f) use ($stars){ return (int)$f['rating']===$stars; }));
        $pct   = $total > 0 ? round($count/$total*100) : 0;
      ?>
      <div style="display:flex;align-items:center;gap:1rem;margin-bottom:.75rem">
        <span style="color:#f59e0b;font-size:.9rem;white-space:nowrap;width:80px"><?= str_repeat('★',$stars) ?> <?= $stars ?> star</span>
        <div style="flex:1;background:var(--border);border-radius:50px;height:10px">
          <div style="background:#f59e0b;height:10px;border-radius:50px;width:<?= $pct ?>%"></div>
        </div>
        <span style="font-size:.85rem;color:var(--muted);width:60px;text-align:right"><?= $count ?> (<?= $pct ?>%)</span>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</div>
</body>
</html>

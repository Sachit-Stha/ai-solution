<?php
// FRONTEND: admin/blog_edit.php
// Backend logic is separated into backend/admin/blog_edit_backend.php
require_once '../backend/admin/blog_edit_backend.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $is_edit ? 'Edit Post' : 'New Post' ?> – AI-Solutions Admin</title>
<link rel="stylesheet" href="../css/style.css">
<style>
.emoji-grid{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.5rem}
.emoji-opt{width:42px;height:42px;border:2px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;cursor:pointer;transition:.15s;background:var(--white)}
.emoji-opt:hover,.emoji-opt.selected{border-color:var(--pl);background:#e0f2fe}
.editor-toolbar{display:flex;gap:.4rem;flex-wrap:wrap;padding:.5rem;background:#f8fafc;border:1.5px solid var(--border);border-bottom:none;border-radius:8px 8px 0 0}
.toolbar-btn{padding:.3rem .65rem;border:1px solid var(--border);background:var(--white);border-radius:5px;cursor:pointer;font-size:.82rem;font-weight:600;transition:.15s}
.toolbar-btn:hover{background:var(--primary);color:#fff;border-color:var(--primary)}
#content{border-radius:0 0 8px 8px;min-height:320px;font-family:monospace;font-size:.88rem}
</style>
</head>
<body style="background:#f0f4f8">

<div class="admin-nav">
  <div class="brand">
    <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
    AI-Solutions Admin
  </div>
  <div class="user-info">
    👤 <?= htmlspecialchars($_SESSION['admin_user']) ?>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="menu-label">Main</div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="enquiries.php">📩 Enquiries</a>
    <a href="feedback.php">⭐ Feedback</a>
    <a href="blog.php" class="active">📝 Blog Posts</a>
    <div class="menu-label">Site</div>
    <a href="../blog.php" target="_blank">📖 View Blog</a>
    <a href="../index.php" target="_blank">🌐 View Website</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <div class="admin-main">
    <div class="admin-page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem">
      <div>
        <h1><?= $is_edit ? 'Edit Post' : 'New Blog Post' ?></h1>
        <p><?= $is_edit ? 'Update your existing article' : 'Write and publish a new article' ?></p>
      </div>
      <a href="blog.php" style="color:var(--muted);text-decoration:none;font-size:.9rem">← Back to Posts</a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?>
      <?php if ($is_edit): ?>
      <a href="../blog/post.php?slug=<?= urlencode($post['slug']) ?>" target="_blank" style="color:var(--success);font-weight:600;margin-left:.5rem">View post →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <form method="POST">
      <div style="display:grid;grid-template-columns:1fr 320px;gap:1.5rem;align-items:start">

        <div>
          <div class="admin-card">
            <h2>Post Content</h2>
            <div class="form-group">
              <label for="title">Title <span style="color:#dc2626">*</span></label>
              <input type="text" id="title" name="title" placeholder="Enter post title..." required value="<?= htmlspecialchars($post['title']) ?>" oninput="generateSlug(this.value)">
            </div>
            <div class="form-group">
              <label for="slug">URL Slug</label>
              <input type="text" id="slug" name="slug" placeholder="auto-generated-from-title" value="<?= htmlspecialchars($post['slug']) ?>">
              <small style="color:var(--muted);font-size:.8rem">Will appear as: /blog/post.php?slug=<span id="slugPreview"><?= htmlspecialchars($post['slug']) ?></span></small>
            </div>
            <div class="form-group">
              <label for="excerpt">Excerpt / Summary</label>
              <textarea id="excerpt" name="excerpt" placeholder="Short description shown on blog listing..." style="min-height:80px"><?= htmlspecialchars($post['excerpt']) ?></textarea>
            </div>
            <div class="form-group">
              <label>Content <span style="color:#dc2626">*</span> <small style="color:var(--muted);font-weight:400">(HTML supported)</small></label>
              <div class="editor-toolbar">
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;h2&gt;','&lt;/h2&gt;')">H2</button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;h3&gt;','&lt;/h3&gt;')">H3</button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;p&gt;','&lt;/p&gt;')">P</button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;strong&gt;','&lt;/strong&gt;')"><strong>B</strong></button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;em&gt;','&lt;/em&gt;')"><em>I</em></button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;ul&gt;\n  &lt;li&gt;','&lt;/li&gt;\n&lt;/ul&gt;')">UL</button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;blockquote&gt;','&lt;/blockquote&gt;')">❝</button>
                <button type="button" class="toolbar-btn" onclick="wrap('&lt;a href=&quot;&quot;&gt;','&lt;/a&gt;')">Link</button>
              </div>
              <textarea id="content" name="content" placeholder="Write your article content using HTML tags..." required><?= htmlspecialchars($post['content']) ?></textarea>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:1.5rem">
          <div class="admin-card">
            <h2>Publish</h2>
            <div class="form-group">
              <label for="status">Status</label>
              <select id="status" name="status">
                <option value="draft" <?= $post['status']==='draft'?'selected':'' ?>>📋 Draft</option>
                <option value="published" <?= $post['status']==='published'?'selected':'' ?>>✅ Published</option>
              </select>
            </div>
            <div class="form-group">
              <label for="author">Author</label>
              <input type="text" id="author" name="author" value="<?= htmlspecialchars($post['author']) ?>">
            </div>
            <button type="submit" class="submit-btn"><?= $is_edit ? '💾 Update Post' : '🚀 Save Post' ?></button>
            <?php if ($is_edit && !empty($post['slug'])): ?>
            <a href="../blog/post.php?slug=<?= urlencode($post['slug']) ?>" target="_blank" style="display:block;text-align:center;margin-top:.75rem;font-size:.85rem;color:var(--pl);text-decoration:none">👁 Preview post →</a>
            <?php endif; ?>
          </div>

          <div class="admin-card">
            <h2>Category</h2>
            <select name="category">
              <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat ?>" <?= $post['category']===$cat?'selected':'' ?>><?= $cat ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="admin-card">
            <h2>Post Icon</h2>
            <input type="hidden" name="image_emoji" id="selectedEmoji" value="<?= htmlspecialchars($post['image_emoji']) ?>">
            <div style="text-align:center;font-size:3rem;margin-bottom:.75rem" id="emojiDisplay"><?= $post['image_emoji'] ?></div>
            <div class="emoji-grid">
              <?php foreach ($emojis as $e): ?>
              <div class="emoji-opt <?= $post['image_emoji']===$e?'selected':'' ?>" onclick="selectEmoji('<?= $e ?>')"><?= $e ?></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

      </div>
    </form>
  </div>
</div>

<script>
function generateSlug(title) {
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  const f = document.getElementById('slug');
  if (!f.dataset.manual) { f.value = slug; document.getElementById('slugPreview').textContent = slug; }
}
document.getElementById('slug').addEventListener('input', function() {
  this.dataset.manual = '1';
  document.getElementById('slugPreview').textContent = this.value;
});
function selectEmoji(e) {
  document.getElementById('selectedEmoji').value = e;
  document.getElementById('emojiDisplay').textContent = e;
  document.querySelectorAll('.emoji-opt').forEach(el => el.classList.remove('selected'));
  event.target.classList.add('selected');
}
function wrap(open, close) {
  const ta = document.getElementById('content');
  const s = ta.selectionStart, e = ta.selectionEnd;
  ta.value = ta.value.substring(0,s) + open + ta.value.substring(s,e) + close + ta.value.substring(e);
  ta.focus();
}
</script>
</body>
</html>

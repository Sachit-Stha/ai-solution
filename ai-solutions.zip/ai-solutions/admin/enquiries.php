<?php
// FRONTEND: admin/enquiries.php
// Backend logic is separated into backend/admin/enquiries_backend.php
require_once '../backend/admin/enquiries_backend.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enquiries – AI-Solutions Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#f0f4f8">

<div class="admin-nav">
  <div class="brand">
    <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
    AI-Solutions Admin
  </div>
  <div class="user-info">
    👤 <?= htmlspecialchars($_SESSION['admin_user']) ?>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="menu-label">Main</div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="enquiries.php" class="active">📩 Enquiries</a>
    <a href="feedback.php">⭐ Feedback</a>
    <a href="blog.php">📝 Blog Posts</a>
    <div class="menu-label">Site</div>
    <a href="../blog.php" target="_blank">📖 View Blog</a>
    <a href="../index.php" target="_blank">🌐 View Website</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <div class="admin-main">
    <div class="admin-page-header">
      <h1>Customer Enquiries</h1>
      <p>All enquiries submitted through the Contact Us form</p>
    </div>

    <?php if ($message_alert): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message_alert) ?></div>
    <?php endif; ?>

    <?php if ($view_item): ?>
    <!-- DETAIL VIEW -->
    <div class="admin-card">
      <h2>Enquiry Details – <?= htmlspecialchars($view_item['name']) ?>
        <a href="enquiries.php" style="font-size:.85rem;font-weight:400;color:var(--muted);text-decoration:none;margin-left:1rem">← Back to list</a>
      </h2>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
        <?php
        $fields = [
          'Full Name'=>$view_item['name'],'Email'=>$view_item['email'],
          'Phone'=>$view_item['phone'],'Company'=>$view_item['company'],
          'Country'=>$view_item['country'],'Job Title'=>$view_item['job_title']??'—',
          'Interest'=>ucwords(str_replace('_',' ',$view_item['interest']??'')),
          'Status'=>ucfirst($view_item['status']),'Submitted'=>$view_item['submitted_at'],
        ];
        foreach ($fields as $label => $val): ?>
        <div style="padding:.75rem;background:var(--bg);border-radius:8px">
          <div style="font-size:.78rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:.2rem"><?= $label ?></div>
          <div style="font-weight:600;color:var(--text)"><?= htmlspecialchars($val) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="margin-top:1rem;padding:.75rem;background:var(--bg);border-radius:8px">
        <div style="font-size:.78rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:.5rem">Message / Job Details</div>
        <p style="color:var(--text);line-height:1.7"><?= nl2br(htmlspecialchars($view_item['job_details'])) ?></p>
      </div>
      <div style="margin-top:1rem;display:flex;gap:.75rem">
        <a href="enquiries.php?delete=<?= $view_item['id'] ?>" class="btn-sm btn-danger" onclick="return confirm('Delete this enquiry?')">🗑 Delete</a>
        <a href="enquiries.php" class="btn-sm">← Back to List</a>
      </div>
    </div>

    <?php else: ?>
    <!-- LIST VIEW -->
    <div class="admin-card">
      <h2>All Enquiries (<?= count($enquiries) ?>)</h2>
      <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Search by name, company, country..." onkeyup="filterTable()">
        <select id="statusFilter" onchange="filterTable()">
          <option value="">All Status</option>
          <option value="new">New</option>
          <option value="read">Read</option>
        </select>
      </div>
      <div style="overflow-x:auto">
        <table class="data-table" id="enquiryTable">
          <thead>
            <tr><th>#</th><th>Name</th><th>Email</th><th>Company</th><th>Country</th><th>Interest</th><th>Date</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php $rowNum=1; foreach ($enquiries as $row): ?>
            <tr>
              <td><?= $rowNum++ ?></td>
              <td><strong><?= htmlspecialchars($row['name']) ?></strong></td>
              <td style="font-size:.85rem"><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['company']) ?></td>
              <td><?= htmlspecialchars($row['country']) ?></td>
              <td><?= htmlspecialchars(ucwords(str_replace('_',' ',$row['interest']??'-'))) ?></td>
              <td style="white-space:nowrap;font-size:.82rem;color:var(--muted)"><?= substr($row['submitted_at'],0,10) ?></td>
              <td><span class="badge badge-<?= $row['status']==='new'?'new':'read' ?>"><?= ucfirst($row['status']) ?></span></td>
              <td>
                <div class="table-actions">
                  <a href="enquiries.php?view=<?= $row['id'] ?>" class="btn-sm">View</a>
                  <a href="enquiries.php?delete=<?= $row['id'] ?>" class="btn-sm btn-danger" onclick="return confirm('Delete this enquiry permanently?')">Delete</a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function filterTable() {
  const q = document.getElementById('searchInput').value.toLowerCase();
  const status = document.getElementById('statusFilter').value.toLowerCase();
  document.querySelectorAll('#enquiryTable tbody tr').forEach(row => {
    const text = row.textContent.toLowerCase();
    const rowStatus = row.querySelector('.badge')?.textContent.toLowerCase() || '';
    row.style.display = (!q || text.includes(q)) && (!status || rowStatus.includes(status)) ? '' : 'none';
  });
}
</script>
</body>
</html>

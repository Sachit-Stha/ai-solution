<?php
// FRONTEND: admin/dashboard.php
// Backend logic is separated into backend/admin/dashboard_backend.php
require_once '../backend/admin/dashboard_backend.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard – AI-Solutions Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#f0f4f8">

<div class="admin-nav">
  <div class="brand">
    <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
    AI-Solutions Admin
  </div>
  <div class="user-info">
    👤 <?= htmlspecialchars($_SESSION['admin_user']) ?>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="menu-label">Main</div>
    <a href="dashboard.php" class="active">📊 Dashboard</a>
    <a href="enquiries.php">📩 Enquiries</a>
    <a href="feedback.php">⭐ Feedback</a>
    <a href="blog.php">📝 Blog Posts</a>
    <div class="menu-label">Site</div>
    <a href="../blog.php" target="_blank">📖 View Blog</a>
    <a href="../index.php" target="_blank">🌐 View Website</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <div class="admin-main">
    <div class="admin-page-header">
      <h1>Dashboard</h1>
      <p>Overview of AI-Solutions enquiries and activity</p>
    </div>

    <div class="stat-cards">
      <div class="stat-card"><div class="num"><?= $stats['total_enquiries'] ?></div><div class="lbl">📩 Total Enquiries</div></div>
      <div class="stat-card green"><div class="num"><?= $stats['new_enquiries'] ?></div><div class="lbl">🆕 New (Unread)</div></div>
      <div class="stat-card amber"><div class="num"><?= $stats['total_feedback'] ?></div><div class="lbl">⭐ Feedback Received</div></div>
      <div class="stat-card red"><div class="num"><?= $stats['countries'] ?></div><div class="lbl">🌍 Countries Reached</div></div>
    </div>

    <div class="admin-card">
      <h2>Recent Enquiries</h2>
      <div style="overflow-x:auto">
        <table class="data-table">
          <thead>
            <tr><th>#</th><th>Name</th><th>Company</th><th>Country</th><th>Interest</th><th>Date</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php $rowNum=1; foreach ($recent as $row): ?>
            <tr>
              <td><?= $rowNum++ ?></td>
              <td><strong><?= htmlspecialchars($row['name']) ?></strong></td>
              <td><?= htmlspecialchars($row['company']) ?></td>
              <td><?= htmlspecialchars($row['country']) ?></td>
              <td><?= htmlspecialchars(ucwords(str_replace('_',' ',$row['interest']??'-'))) ?></td>
              <td style="white-space:nowrap;font-size:.85rem;color:var(--muted)"><?= htmlspecialchars(substr($row['submitted_at'],0,16)) ?></td>
              <td><span class="badge badge-<?= $row['status']==='new'?'new':'read' ?>"><?= ucfirst($row['status']) ?></span></td>
              <td><a href="enquiries.php?view=<?= $row['id'] ?>" class="btn-sm">View</a></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="margin-top:1rem;text-align:right">
        <a href="enquiries.php" class="btn-sm" style="background:var(--primary);color:#fff;border-color:var(--primary)">View All Enquiries →</a>
      </div>
    </div>

    <div class="admin-card">
      <h2>Enquiries by Interest Area</h2>
      <?php $total_b = array_sum($breakdown); foreach ($breakdown as $label => $count):
        $pct = $total_b > 0 ? round($count/$total_b*100) : 0; ?>
      <div style="margin-bottom:.9rem">
        <div style="display:flex;justify-content:space-between;font-size:.88rem;margin-bottom:.3rem">
          <span style="font-weight:600"><?= $label ?></span>
          <span style="color:var(--muted)"><?= $count ?> (<?= $pct ?>%)</span>
        </div>
        <div style="background:var(--border);border-radius:50px;height:8px">
          <div style="background:var(--pl);height:8px;border-radius:50px;width:<?= $pct ?>%"></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</body>
</html>

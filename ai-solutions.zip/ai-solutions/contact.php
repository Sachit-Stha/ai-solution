<?php
// FRONTEND: contact.php
// Backend logic is separated into backend/contact_backend.php
require_once 'backend/contact_backend.php';
$pageTitle = "Contact Us – AI-Solutions";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<div class="page-hero">
  <div class="breadcrumb"><a href="index.php">Home</a> / Contact Us</div>
  <h1>Get In Touch</h1>
  <p>Tell us about your project and we'll respond within 24 hours.</p>
</div>

<section>
  <div class="section-inner">
    <div style="display:grid;grid-template-columns:1fr 1.6fr;gap:3rem;align-items:start">

      <!-- INFO PANEL -->
      <div>
        <h2 class="section-title" style="font-size:1.5rem">Why Contact Us?</h2>
        <p style="color:var(--muted);margin-bottom:2rem">Whether you're looking to schedule a demo, explore a partnership, or discuss a challenge — our team is ready to help.</p>
        <div style="display:flex;flex-direction:column;gap:1.2rem">
          <?php
          $items = [
            ['📅','Schedule a Demo','See our AI solutions in action with a personalised demonstration.'],
            ['💡','Discuss a Project','Share your challenge and we will propose a solution that fits your needs.'],
            ['🤝','Explore Partnership','Interested in partnering with AI-Solutions? We are always open to collaborations.'],
            ['📞','General Enquiry','Our team typically responds within 24 hours on business days.'],
          ];
          foreach ($items as $item): ?>
          <div style="display:flex;gap:1rem;align-items:flex-start;padding:1rem;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius)">
            <div style="font-size:1.5rem;flex-shrink:0"><?= $item[0] ?></div>
            <div>
              <strong style="display:block;font-size:.95rem;color:var(--primary);margin-bottom:.2rem"><?= $item[1] ?></strong>
              <span style="font-size:.88rem;color:var(--muted)"><?= $item[2] ?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <div style="margin-top:2rem;padding:1.2rem;background:var(--primary);border-radius:var(--radius);color:#fff">
          <div style="font-size:.85rem;opacity:.8;margin-bottom:.4rem">📧 Email us directly</div>
          <div style="font-weight:600">info@ai-solutions.com</div>
          <div style="font-size:.85rem;opacity:.8;margin-top:.75rem;margin-bottom:.4rem">📞 Phone</div>
          <div style="font-weight:600">+44 191 500 0000</div>
          <div style="font-size:.85rem;opacity:.8;margin-top:.75rem;margin-bottom:.4rem">📍 Address</div>
          <div style="font-weight:600">AI-Solutions Ltd, Sunderland, UK, SR1 1AA</div>
        </div>
      </div>

      <!-- FORM -->
      <div class="form-card">
        <h2 style="font-size:1.4rem;font-weight:800;color:var(--primary);margin-bottom:.3rem">Send Us a Message</h2>
        <p style="color:var(--muted);font-size:.9rem;margin-bottom:1.5rem">Fields marked <span style="color:#dc2626">*</span> are required.</p>

        <?php if ($success): ?>
        <div class="alert alert-success">
          ✅ <strong>Thank you!</strong> Your enquiry has been received. We will be in touch within 24 hours.
        </div>
        <?php elseif ($error): ?>
        <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST" action="contact.php" id="contactForm" novalidate>
          <div class="form-row">
            <div class="form-group">
              <label for="name">Full Name <span style="color:#dc2626">*</span></label>
              <input type="text" id="name" name="name" placeholder="e.g. John Smith" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label for="email">Email Address <span style="color:#dc2626">*</span></label>
              <input type="email" id="email" name="email" placeholder="john@company.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="phone">Phone Number <span style="color:#dc2626">*</span></label>
              <input type="tel" id="phone" name="phone" placeholder="+44 7700 900000" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label for="company">Company Name <span style="color:#dc2626">*</span></label>
              <input type="text" id="company" name="company" placeholder="Your Company Ltd" required value="<?= htmlspecialchars($_POST['company'] ?? '') ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="country">Country <span style="color:#dc2626">*</span></label>
              <select id="country" name="country" required>
                <option value="">Select country...</option>
                <?php foreach (['United Kingdom','United States','Canada','Australia','India','Germany','France','UAE','Singapore','Nepal','Other'] as $c): ?>
                <option value="<?= $c ?>" <?= (($_POST['country'] ?? '') === $c) ? 'selected' : '' ?>><?= $c ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="job_title">Job Title</label>
              <input type="text" id="job_title" name="job_title" placeholder="e.g. CTO, Operations Manager" value="<?= htmlspecialchars($_POST['job_title'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label for="interest">I am interested in...</label>
            <select id="interest" name="interest">
              <option value="">Select a topic...</option>
              <?php
              $interests = ['virtual_assistant'=>'AI Virtual Assistant','demo'=>'Schedule a Demo','prototyping'=>'Rapid Prototyping','automation'=>'Process Automation','analytics'=>'Analytics & Insights','events'=>'Join Promotional Events','partnership'=>'Partnership Opportunity','other'=>'General Enquiry'];
              foreach ($interests as $val => $label): ?>
              <option value="<?= $val ?>" <?= (($_POST['interest'] ?? '') === $val) ? 'selected' : '' ?>><?= $label ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="job_details">Message / Job Details <span style="color:#dc2626">*</span></label>
            <textarea id="job_details" name="job_details" placeholder="Tell us about your project, challenges, or questions..." required><?= htmlspecialchars($_POST['job_details'] ?? '') ?></textarea>
          </div>
          <div class="alert alert-error" id="alertError" style="display:none">⚠️ Please fill in all required fields correctly.</div>
          <button type="submit" class="submit-btn">📨 Send Enquiry</button>
        </form>
        <?php endif; ?>
      </div>

    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
</body>
</html>

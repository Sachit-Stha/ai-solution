
```
# AI-Solutions Website
### CET333 Product Development – Sachit Shrestha

```
ai-solutions/
├── index.php            - Home page
├── services.php         - Services page
├── contact.php          - Contact Us form (saves to DB)
├── gallery.php          - Photo gallery & events
├── css/
│   └── style.css        - Main stylesheet
├── js/
│   └── main.js          - Chatbot, nav, gallery filter
├── includes/
│   ├── nav.php          - Shared navbar + chatbot widget
│   └── footer.php       - Shared footer
├── admin/
│   ├── login.php        - Admin login
│   ├── logout.php       - Session logout
│   ├── dashboard.php    - Admin dashboard
│   ├── enquiries.php    - View/delete enquiries
│   └── feedback.php     - View feedback & ratings
└── ai_solutions_db.sql  - Database setup script
```

---

## Local Setup (XAMPP)

1. Install XAMPP from https://www.apachefriends.org
2. Start Apache and MySQL in the XAMPP Control Panel
3. Copy this folder to: `C:\xampp\htdocs\ai-solutions\`
4. Open phpMyAdmin: http://localhost/phpmyadmin
5. Create a new database called `ai_solutions_db`
6. Import `ai_solutions_db.sql` (sample data + tables included)
7. Open the site: http://localhost/ai-solutions/

---

## Admin Login

- URL: http://localhost/ai-solutions/admin/login.php
- Username: admin
- Password: Admin@1234

>  Change these credentials after first login in production.

---

##  Features

| Page | Features |
|------|----------|
| Home | Hero, stats bar, services overview, testimonials, CTA |
| Services | Detailed breakdown of all 4 AI services + tech stack |
| Contact Us | Full form (name, email, phone, company, country, job title, interest, message) with PHP/MySQL backend |
| Gallery | Photo gallery with category filter + upcoming events |
| Chatbot | Aria – AI virtual assistant with quick-reply buttons and typing indicator |
| Admin Login | Secure session-based authentication |
| Admin Dashboard | Stats, recent enquiries, interest breakdown chart |
| Admin Enquiries | View, search, filter, delete enquiries |
| Admin Feedback | View ratings, rating distribution chart |

---

##  Tech Stack

- Frontend: HTML5, CSS3, JavaScript 
- Backend: PHP 8.0+
- Database: MySQL 8.0 (via MySQLi with prepared statements)
- Server: Apache (XAMPP)
- Security: Input sanitisation, prepared statements, session auth, password_hash()

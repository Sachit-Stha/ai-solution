// js/admin.js
// Shared admin sidebar, auth guard, and utility functions

// ── AUTH GUARD ────────────────────────────────────────────────────────────────
async function requireAdminAuth() {
  try {
    const res  = await fetch('../api/admin/auth.php?action=check');
    const json = await res.json();
    if (!json.success) { window.location.href = '/ai-solutions/admin/login.html'; return null; }
    document.getElementById('adminUser').textContent = '👤 ' + json.data.user;
    return json.data.user;
  } catch {
    window.location.href = '/ai-solutions/admin/login.html';
    return null;
  }
}

// ── LOGOUT ────────────────────────────────────────────────────────────────────
async function adminLogout() {
  await fetch('../api/admin/auth.php?action=logout', { method: 'POST' });
  window.location.href = '/ai-solutions/admin/login.html';
}

// ── SIDEBAR HTML ──────────────────────────────────────────────────────────────
function renderAdminSidebar(activePage) {
  const pages = [
    { href: '/ai-solutions/admin/dashboard.html',  icon: '📊', label: 'Dashboard'  },
    { href: '/ai-solutions/admin/enquiries.html',  icon: '📩', label: 'Enquiries'  },
    { href: '/ai-solutions/admin/feedback.html',   icon: '⭐', label: 'Feedback'   },
    { href: '/ai-solutions/admin/blog.html',       icon: '📝', label: 'Blog Posts' },
  ];
  const links = pages.map(p =>
    `<a href="${p.href}" class="${activePage===p.label?'active':''}">${p.icon} ${p.label}</a>`
  ).join('');
  return `
    <div class="admin-sidebar">
      <div class="menu-label">Main</div>
      ${links}
      <div class="menu-label">Site</div>
      <a href="/ai-solutions/blog.html" target="_blank">📖 View Blog</a>
      <a href="/ai-solutions/index.html" target="_blank">🌐 View Website</a>
      <a href="#" onclick="adminLogout()">🚪 Logout</a>
    </div>`;
}

// ── ADMIN NAV HTML ────────────────────────────────────────────────────────────
function renderAdminNav() {
  return `
    <div class="admin-nav">
      <div class="brand">
        <span style="background:var(--accent);width:28px;height:28px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff">AI</span>
        AI-Solutions Admin
      </div>
      <div class="user-info">
        <span id="adminUser">👤 ...</span>
        <a href="#" class="logout-btn" onclick="adminLogout()">Logout</a>
      </div>
    </div>`;
}

// ── ALERT HELPERS ─────────────────────────────────────────────────────────────
function showAlert(id, message, type = 'success') {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = message;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 4000);
}

// ── NUMBER BADGE ──────────────────────────────────────────────────────────────
function statCard(num, label, colorClass = '') {
  return `<div class="stat-card ${colorClass}"><div class="num">${num}</div><div class="lbl">${label}</div></div>`;
}

// ── SKELETON ROWS ─────────────────────────────────────────────────────────────
function skeletonRows(cols, rows = 5) {
  return Array.from({length: rows}, () =>
    `<tr>${Array.from({length: cols}, () =>
      `<td><div style="height:16px;background:linear-gradient(90deg,#e2e8f0 25%,#f1f5f9 50%,#e2e8f0 75%);background-size:200% 100%;animation:shimmer 1.5s infinite;border-radius:4px"></div></td>`
    ).join('')}</tr>`
  ).join('');
}

// ── DATE FORMAT ───────────────────────────────────────────────────────────────
function fmtDate(dt, full = false) {
  if (!dt) return '—';
  const d = new Date(dt);
  return full
    ? d.toLocaleDateString('en-GB', {day:'numeric',month:'long',year:'numeric'})
    : d.toISOString().slice(0,10);
}

// Add shimmer keyframe if not already in CSS
const style = document.createElement('style');
style.textContent = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`;
document.head.appendChild(style);

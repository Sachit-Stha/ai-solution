// Mobile nav toggle
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
if (hamburger) hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));

// Chatbot
const chatToggle = document.getElementById('chatToggle');
const chatWindow = document.getElementById('chatWindow');
const chatClose  = document.getElementById('chatClose');
const chatMessages = document.getElementById('chatMessages');
const chatInput  = document.getElementById('chatInput');
const chatSend   = document.getElementById('chatSend');

const responses = {
  'hello|hi there|^hi$|hey|good morning|good afternoon': "Hi there! 👋 I'm Aria, AI-Solutions' virtual assistant. How can I help you today?",

  'service|solution|offer|product|what do you do': "We offer four core solutions: 🤖 AI Virtual Assistants, ⚡ Rapid Prototyping, 🔄 Process Automation, and 📊 Analytics &amp; Insights. Want details on any of these?",

  'virtual assistant|chatbot.*work|how.*aria': "Our AI Virtual Assistant (like me!) understands natural language, resolves common queries instantly, and hands off to a human when things get complex. It works 24/7 across web, mobile and messaging.",

  'prototyp': "Our Rapid Prototyping service takes you from idea to a working product in as little as 5 business days, combining AI-generated scaffolding with expert engineering.",

  'automat': "Process Automation helps you eliminate repetitive manual work — think invoice processing, onboarding, or IT helpdesk tickets — often cutting costs by up to 40%.",

  'analytic|data|insight|dashboard': "Our Analytics &amp; Insights platform turns your raw data into actionable dashboards, with predictive trends and natural-language data queries.",

  'demo|schedule|book|appointment|trial': "We'd love to show you what we can do! 🎯 Please fill in our <a href='contact.php' style='color:var(--accent)'>Contact form</a> to schedule a personalised demo.",

  'price|cost|pricing|quote|budget': "Our pricing is tailored to each client's needs and scope. Please <a href='contact.php' style='color:var(--accent)'>get in touch</a> and our team will provide a custom quote within 24 hours.",

  'contact|email|phone|reach|get in touch': "You can reach us at 📧 info@ai-solutions.com or 📞 +44 191 500 0000. Or use our <a href='contact.php' style='color:var(--accent)'>Contact page</a>.",

  'location|address|where are you|based in|office': "We are based in Sunderland, UK 🇬🇧 — but we work with clients across 40+ countries worldwide, fully remote-friendly.",

  'event|gallery|webinar|join.*event|promotional': "We host regular technical events and webinars! Check our <a href='gallery.php' style='color:var(--accent)'>Gallery</a> for highlights of past events, or let us know if you'd like to join an upcoming one.",

  'industr|sector|who do you work with|clients': "We work across many industries — technology, finance, logistics, retail, and more. Our AI solutions adapt to any sector's specific workflow needs.",

  'support|after.*deliver|maintenance|help after': "Yes! We offer ongoing support and maintenance packages after delivery, including monitoring, updates, and continuous AI model improvements.",

  'human|agent|person|staff|talk|real person': "I'll flag this for a human team member. 🙋 Please leave your details via our <a href='contact.php' style='color:var(--accent)'>Contact form</a> and someone will reach out within 24 hours.",

  'feedback|review|rate|rating': "We would love your feedback! ⭐ Please visit our <a href='feedback.php' style='color:var(--accent)'>Feedback page</a> to leave a review.",

  'blog|article|read more|news': "Check out our <a href='blog.php' style='color:var(--accent)'>Blog</a> for the latest insights on AI, automation, and digital transformation!",

  'job|career|hiring|work for you|vacanc': "We are always looking for great talent! Feel free to reach out via the Contact form with your CV.",

  'chatbot|aria|who are you|are you (a |)(robot|ai|bot)': "I'm Aria, an AI-powered virtual assistant built by AI-Solutions! I can answer questions, help you find information, or connect you with our team.",

  'thank|thanks|cheers|appreciate': "You're welcome! 😊 Is there anything else I can help with?",

  'bye|goodbye|see you|that.?s all': "Thanks for chatting! 👋 Feel free to reach out anytime. Have a great day!",
};

function getBotReply(msg) {
  const lower = msg.toLowerCase();
  for (const [pattern, reply] of Object.entries(responses)) {
    const regex = new RegExp(pattern, 'i');
    if (regex.test(lower)) return reply;
  }
  return "Thanks for your message! For detailed assistance, please use our <a href='contact.php' style='color:var(--accent)'>Contact page</a> and our team will respond within 24 hours. Is there anything else I can help with? 😊";
}

function addMsg(html, sender) {
  const typing = chatMessages.querySelector('.typing-indicator');
  if (typing) typing.remove();
  const div = document.createElement('div');
  div.className = `msg ${sender}`;
  div.innerHTML = html;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTyping() {
  const div = document.createElement('div');
  div.className = 'typing-indicator';
  div.innerHTML = '<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>';
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function sendMessage() {
  const msg = chatInput.value.trim();
  if (!msg) return;
  addMsg(msg, 'user');
  chatInput.value = '';
  showTyping();
  setTimeout(() => addMsg(getBotReply(msg), 'bot'), 900);
}

if (chatToggle) {
  chatToggle.addEventListener('click', () => chatWindow.classList.toggle('open'));
  chatClose.addEventListener('click', () => chatWindow.classList.remove('open'));
  chatSend.addEventListener('click', sendMessage);
  chatInput.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', () => { chatInput.value = btn.dataset.q; sendMessage(); });
  });
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
  });
});

// Gallery filter
const filterBtns = document.querySelectorAll('.filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item[data-cat]');
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cat = btn.dataset.cat;
    galleryItems.forEach(item => {
      item.style.display = (cat === 'all' || item.dataset.cat === cat) ? '' : 'none';
    });
  });
});

// Contact form client-side validation
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', function(e) {
    const required = contactForm.querySelectorAll('[required]');
    let valid = true;
    required.forEach(field => {
      field.style.borderColor = '';
      if (!field.value.trim()) { field.style.borderColor = '#dc2626'; valid = false; }
    });
    const email = document.getElementById('email');
    if (email && email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
      email.style.borderColor = '#dc2626'; valid = false;
    }
    if (!valid) { e.preventDefault(); document.getElementById('alertError').style.display = 'block'; }
  });
}

// js/components.js
// Shared nav, footer and chatbot for all pure HTML pages
// window._PAGE_ROOT is set by each page before this script loads:
//   Root-level pages:  window._PAGE_ROOT = '/ai-solutions/'
//   /blog/ pages:      window._PAGE_ROOT = '/ai-solutions/'  (same — absolute)
//   /admin/ pages:     window._PAGE_ROOT = '/ai-solutions/'  (same — absolute)

function getROOT() {
  return window._PAGE_ROOT || '/ai-solutions/';
}

// ── NAV ───────────────────────────────────────────────────────────────────────
function renderNav(activePage, ROOT) {
  const pages = [
    { href:'index.html',    label:'Home'     },
    { href:'services.html', label:'Services' },
    { href:'gallery.html',  label:'Gallery'  },
    { href:'blog.html',     label:'Blog'     },
    { href:'feedback.html', label:'Feedback' },
  ];
  const links = pages.map(p =>
    `<li><a href="${ROOT}${p.href}" ${activePage===p.label?'class="active"':''}>${p.label}</a></li>`
  ).join('');
  return `
  <nav>
    <a href="${ROOT}index.html" class="nav-logo"><div class="logo-icon">AI</div><span>AI-Solutions</span></a>
    <ul class="nav-links" id="navLinks">
      ${links}
      <li><a href="${ROOT}contact.html" class="nav-cta ${activePage==='Contact Us'?'active':''}">Contact Us</a></li>
    </ul>
    <button class="hamburger" id="hamburger"><span></span><span></span><span></span></button>
  </nav>`;
}

// ── FOOTER ────────────────────────────────────────────────────────────────────
function renderFooter(ROOT) {
  return `
  <footer>
    <div class="footer-inner">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="footer-logo"><div class="logo-icon" style="width:32px;height:32px;font-size:14px;flex-shrink:0">AI</div> AI-Solutions</div>
          <p>Leveraging AI to transform the digital employee experience.</p>
        </div>
        <div class="footer-col"><h4>Company</h4><ul>
          <li><a href="${ROOT}index.html">Home</a></li>
          <li><a href="${ROOT}services.html">Services</a></li>
          <li><a href="${ROOT}gallery.html">Gallery</a></li>
          <li><a href="${ROOT}blog.html">Blog</a></li>
          <li><a href="${ROOT}feedback.html">Feedback</a></li>
          <li><a href="${ROOT}contact.html">Contact Us</a></li>
        </ul></div>
        <div class="footer-col"><h4>Solutions</h4><ul>
          <li><a href="${ROOT}services.html">Virtual Assistant</a></li>
          <li><a href="${ROOT}services.html">AI Prototyping</a></li>
          <li><a href="${ROOT}services.html">Automation</a></li>
          <li><a href="${ROOT}services.html">Analytics</a></li>
        </ul></div>
        <div class="footer-col"><h4>Contact</h4><ul>
          <li><a href="mailto:info@ai-solutions.com">info@ai-solutions.com</a></li>
          <li><a href="#">+44 191 500 0000</a></li>
          <li><a href="#">Sunderland, UK</a></li>
          <li><a href="${ROOT}admin/login.html">Admin Login</a></li>
        </ul></div>
      </div>
      <div class="footer-bottom">
        <span>&copy; 2026 AI-Solutions Ltd. All rights reserved.</span>
        <span>CET333 Product Development</span>
      </div>
    </div>
  </footer>`;
}

// ── CHATBOT HTML ──────────────────────────────────────────────────────────────
function renderChatbot() {
  return `
  <div class="chatbot-wrapper">
    <div class="chat-window" id="chatWindow">
      <div class="chat-header">
        <div class="chat-avatar">🤖</div>
        <div class="chat-header-info"><strong>Aria – AI Assistant</strong><span>● Online now</span></div>
        <button class="chat-close-btn" id="chatClose">✕</button>
      </div>
      <div class="chat-messages" id="chatMessages">
        <div class="msg bot">👋 Hi! I am Aria. How can I help you today?</div>
      </div>
      <div class="chat-quick-btns" id="chatQuickBtns">
        <button class="quick-btn" data-q="Tell me about your services">Our services</button>
        <button class="quick-btn" data-q="I want to schedule a demo">Schedule demo</button>
        <button class="quick-btn" data-q="How do I contact the team">Contact us</button>
        <button class="quick-btn" data-q="Tell me about upcoming events">Events</button>
        <button class="quick-btn" data-q="What is the pricing?">Pricing</button>
        <button class="quick-btn" data-q="I want to join promotional events">Join events</button>
        <button class="quick-btn" data-q="What industries do you work with?">Industries</button>
        <button class="quick-btn" data-q="Can I speak to a human?">Talk to a human</button>
        <button class="quick-btn" data-q="Where are you located?">Location</button>
        <button class="quick-btn" data-q="Do you offer support after delivery?">Support</button>
      </div>
      <div class="chat-input-row">
        <input type="text" id="chatInput" placeholder="Type a message...">
        <button class="chat-send" id="chatSend">&#10148;</button>
      </div>
    </div>
    <button class="chat-toggle" id="chatToggle">💬<span class="chat-pulse"></span></button>
  </div>`;
}

// ── INIT ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const ROOT   = getROOT();
  const navEl  = document.getElementById('nav-placeholder');
  const active = navEl?.dataset.active || '';

  if (navEl)    navEl.outerHTML    = renderNav(active, ROOT);

  const footerEl = document.getElementById('footer-placeholder');
  if (footerEl) footerEl.outerHTML = renderFooter(ROOT);

  const chatEl = document.getElementById('chatbot-placeholder');
  if (chatEl) {
    chatEl.outerHTML = renderChatbot();
    initChatbot(ROOT);
  }

  document.getElementById('hamburger')?.addEventListener('click', () =>
    document.getElementById('navLinks')?.classList.toggle('open')
  );
});

// ── CHATBOT LOGIC ─────────────────────────────────────────────────────────────
function initChatbot(ROOT) {
  ROOT = ROOT || '/ai-solutions/';
  const responses = {
    'hello|hi there|^hi$|hey|good morning|good afternoon': "Hi there! 👋 I am Aria, AI-Solutions' virtual assistant. How can I help you today?",

    'service|solution|offer|product|what do you do': "We offer four core solutions: 🤖 AI Virtual Assistants, ⚡ Rapid Prototyping, 🔄 Process Automation, and 📊 Analytics &amp; Insights. Want details on any of these?",

    'virtual assistant|chatbot.*work|how.*aria': "Our AI Virtual Assistant (like me!) understands natural language, resolves common queries instantly, and hands off to a human when things get complex. It works 24/7 across web, mobile and messaging.",

    'prototyp': "Our Rapid Prototyping service takes you from idea to a working product in as little as 5 business days, combining AI-generated scaffolding with expert engineering.",

    'automat': "Process Automation helps you eliminate repetitive manual work — think invoice processing, onboarding, or IT helpdesk tickets — often cutting costs by up to 40%.",

    'analytic|data|insight|dashboard': "Our Analytics &amp; Insights platform turns your raw data into actionable dashboards, with predictive trends and natural-language data queries.",

    'demo|schedule|book a|book an|trial': `We would love to show you what we can do! 🎯 Please fill in our <a href='${ROOT}contact.html' style='color:var(--accent)'>Contact form</a> to schedule a personalised demo.`,

    'price|cost|how much|quote|budget': `Our pricing is tailored to each client's needs and scope. Please <a href='${ROOT}contact.html' style='color:var(--accent)'>get in touch</a> and our team will provide a custom quote within 24 hours.`,

    'contact|email|phone number|reach you|get in touch': "You can reach us at 📧 info@ai-solutions.com or 📞 +44 191 500 0000. Or just use the Contact Us page!",

    'location|address|where are you|based in|office': "We are based in Sunderland, UK 🇬🇧 — but we work with clients across 40+ countries worldwide, fully remote-friendly.",

    'event|webinar|join.*event|promotional': `We host regular technical events and webinars! Check our <a href='${ROOT}gallery.html' style='color:var(--accent)'>Gallery page</a> for upcoming events, or let us know via the Contact form if you would like to join one.`,

    'industr|sector|who do you work with|clients': "We work across many industries — technology, finance, logistics, retail, and more. Our AI solutions are designed to adapt to any sector's specific workflow needs.",

    'support|after.*deliver|maintenance|help after': "Yes! We offer ongoing support and maintenance packages after delivery, including monitoring, updates, and continuous AI model improvements.",

    'human|agent|real person|talk to (a |)(human|person|someone)|speak to': `I will flag this for a human team member. 🙋 Please leave your details via our <a href='${ROOT}contact.html' style='color:var(--accent)'>Contact form</a> and someone will reach out within 24 hours.`,

    'feedback|review|rate|rating': `We would love your feedback! ⭐ Please visit our <a href='${ROOT}feedback.html' style='color:var(--accent)'>Feedback page</a> to leave a review.`,

    'blog|article|read more|news': `Check out our <a href='${ROOT}blog.html' style='color:var(--accent)'>Blog</a> for the latest insights on AI, automation, and digital transformation!`,

    'job|career|hiring|work for you|vacanc': "We are always looking for great talent! While we do not have a dedicated careers page yet, feel free to reach out via the Contact form with your CV.",

    'who are you|what are you|are you (a |)(robot|ai|bot)': "I am Aria 🤖, an AI-powered virtual assistant built by AI-Solutions. I can answer common questions, point you to the right resources, or connect you with our human team.",

    'thank|thanks|cheers|appreciate': "You're very welcome! 😊 Is there anything else I can help you with?",

    'bye|goodbye|see you|that.?s all': "Thanks for chatting! 👋 Feel free to reach out anytime. Have a great day!",
  };

  function getBotReply(msg) {
    const lower = msg.toLowerCase();
    for (const [pattern, reply] of Object.entries(responses)) {
      const regex = new RegExp(pattern, 'i');
      if (regex.test(lower)) return reply;
    }
    return `Thanks for your message! For detailed assistance, please use our <a href='${ROOT}contact.html' style='color:var(--accent)'>Contact page</a> and our team will respond within 24 hours. Is there anything else I can help with? 😊`;
  }

  function addMsg(html, sender) {
    document.querySelector('.typing-indicator')?.remove();
    const div = document.createElement('div');
    div.className = `msg ${sender}`;
    div.innerHTML = html;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function showTyping() {
    const div = document.createElement('div');
    div.className = 'typing-indicator';
    div.innerHTML = '<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>';
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function sendMessage() {
    const msg = chatInput.value.trim();
    if (!msg) return;
    addMsg(msg, 'user');
    chatInput.value = '';
    showTyping();
    setTimeout(() => addMsg(getBotReply(msg), 'bot'), 900);
  }

  const chatToggle   = document.getElementById('chatToggle');
  const chatWindow   = document.getElementById('chatWindow');
  const chatClose    = document.getElementById('chatClose');
  const chatMessages = document.getElementById('chatMessages');
  const chatInput    = document.getElementById('chatInput');
  const chatSend     = document.getElementById('chatSend');

  chatToggle?.addEventListener('click', () => chatWindow.classList.toggle('open'));
  chatClose?.addEventListener('click',  () => chatWindow.classList.remove('open'));
  chatSend?.addEventListener('click', sendMessage);
  chatInput?.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });
  document.querySelectorAll('.quick-btn').forEach(btn =>
    btn.addEventListener('click', () => { chatInput.value = btn.dataset.q; sendMessage(); })
  );
}

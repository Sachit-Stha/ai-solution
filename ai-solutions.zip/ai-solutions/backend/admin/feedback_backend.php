<?php
// backend/admin/feedback_backend.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: ../login.php'); exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$message_alert = '';
$all_feedback  = [];
$avg = 0; $total = 0; $five_star = 0;

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete']) && $db_ok) {
    $stmt = $conn->prepare("DELETE FROM feedback WHERE id=?");
    $stmt->bind_param('i', (int)$_GET['delete']);
    $stmt->execute();
    $stmt->close();
    $message_alert = 'Feedback deleted successfully.';
}

// Fetch all feedback
if ($db_ok) {
    $r = $conn->query("SELECT * FROM feedback ORDER BY submitted_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $all_feedback[] = $row;

    $r2 = $conn->query("SELECT COUNT(*) as cnt, AVG(rating) as avg_r, SUM(rating=5) as five FROM feedback");
    if ($r2) {
        $row2      = $r2->fetch_assoc();
        $total     = (int)$row2['cnt'];
        $avg       = round((float)$row2['avg_r'], 1);
        $five_star = (int)$row2['five'];
    }
    $conn->close();
}

// Demo fallback
if (empty($all_feedback)) {
    $all_feedback = [
        ['id'=>6,'name'=>'Priya Sharma',    'email'=>'priya@techcorp.in',      'company'=>'TechCorp India', 'rating'=>5,'message'=>'The virtual assistant exceeded our expectations.',         'submitted_at'=>'2026-05-18 14:22:00'],
        ['id'=>5,'name'=>'James Wilson',    'email'=>'james@brightpath.co.uk', 'company'=>'BrightPath UK',  'rating'=>5,'message'=>'Outstanding service. Delivered on time and on budget.',    'submitted_at'=>'2026-05-17 09:45:00'],
        ['id'=>4,'name'=>'Li Wei',          'email'=>'liwei@horizontech.sg',   'company'=>'Horizon Tech',   'rating'=>4,'message'=>'Very impressed with the prototyping speed.',               'submitted_at'=>'2026-05-16 16:30:00'],
        ['id'=>3,'name'=>'Maria Santos',    'email'=>'maria@novagroup.us',     'company'=>'NovaGroup',      'rating'=>5,'message'=>'AI-Solutions transformed how we handle customer data.',    'submitted_at'=>'2026-05-15 11:10:00'],
        ['id'=>2,'name'=>'Ahmed Al-Rashid', 'email'=>'ahmed@gulfsolutions.ae', 'company'=>'Gulf Solutions', 'rating'=>4,'message'=>'Great product and support team.',                         'submitted_at'=>'2026-05-14 08:55:00'],
        ['id'=>1,'name'=>'Sophie Martin',   'email'=>'sophie@innovatefr.fr',   'company'=>'Innovate France','rating'=>3,'message'=>'Good product but onboarding documentation could improve.','submitted_at'=>'2026-05-13 15:20:00'],
    ];
    $total     = count($all_feedback);
    $avg       = round(array_sum(array_column($all_feedback,'rating')) / $total, 1);
    $five_star = count(array_filter($all_feedback, fn($f) => $f['rating'] == 5));
}

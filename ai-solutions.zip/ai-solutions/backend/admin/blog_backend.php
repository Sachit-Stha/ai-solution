<?php
// backend/admin/blog_backend.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: ../login.php'); exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$alert = '';
$posts = [];

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete']) && $db_ok) {
    $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id=?");
    $stmt->bind_param('i', (int)$_GET['delete']);
    $stmt->execute();
    $stmt->close();
    $alert = 'Post deleted successfully.';
}

// Handle toggle status
if (isset($_GET['toggle']) && is_numeric($_GET['toggle']) && $db_ok) {
    $stmt = $conn->prepare("UPDATE blog_posts SET status = IF(status='published','draft','published') WHERE id=?");
    $stmt->bind_param('i', (int)$_GET['toggle']);
    $stmt->execute();
    $stmt->close();
    $alert = 'Post status updated.';
}

// Fetch all posts
if ($db_ok) {
    $r = $conn->query("SELECT id,title,category,author,status,created_at FROM blog_posts ORDER BY created_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $posts[] = $row;
    $conn->close();
}

$total     = count($posts);
$published = count(array_filter($posts, fn($p) => $p['status'] === 'published'));
$drafts    = $total - $published;

<?php
// backend/admin/dashboard_backend.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: ../login.php'); exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$stats  = ['total_enquiries'=>0,'new_enquiries'=>0,'total_feedback'=>0,'countries'=>0];
$recent = [];

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

if ($db_ok) {
    $r = $conn->query("SELECT COUNT(*) as c FROM enquiries");
    if ($r) $stats['total_enquiries'] = (int)$r->fetch_assoc()['c'];

    $r = $conn->query("SELECT COUNT(*) as c FROM enquiries WHERE status='new'");
    if ($r) $stats['new_enquiries'] = (int)$r->fetch_assoc()['c'];

    $r = $conn->query("SELECT COUNT(*) as c FROM feedback");
    if ($r) $stats['total_feedback'] = (int)$r->fetch_assoc()['c'];

    $r = $conn->query("SELECT COUNT(DISTINCT country) as c FROM enquiries");
    if ($r) $stats['countries'] = (int)$r->fetch_assoc()['c'];

    $r = $conn->query("SELECT id,name,company,country,interest,submitted_at,status FROM enquiries ORDER BY submitted_at DESC LIMIT 5");
    if ($r) while ($row = $r->fetch_assoc()) $recent[] = $row;

    $conn->close();
}

// Demo fallback
if (empty($recent)) {
    $stats = ['total_enquiries'=>47,'new_enquiries'=>12,'total_feedback'=>31,'countries'=>8];
    $recent = [
        ['id'=>47,'name'=>'Priya Sharma',    'company'=>'TechCorp India', 'country'=>'India',         'interest'=>'Virtual Assistant','submitted_at'=>'2026-05-18 14:22','status'=>'new'],
        ['id'=>46,'name'=>'James Wilson',    'company'=>'BrightPath UK',  'country'=>'United Kingdom','interest'=>'Demo',             'submitted_at'=>'2026-05-17 09:45','status'=>'read'],
        ['id'=>45,'name'=>'Li Wei',          'company'=>'Horizon Tech',   'country'=>'Singapore',     'interest'=>'Prototyping',      'submitted_at'=>'2026-05-16 16:30','status'=>'read'],
        ['id'=>44,'name'=>'Maria Santos',    'company'=>'NovaGroup',      'country'=>'United States', 'interest'=>'Analytics',        'submitted_at'=>'2026-05-15 11:10','status'=>'read'],
        ['id'=>43,'name'=>'Ahmed Al-Rashid', 'company'=>'Gulf Solutions', 'country'=>'UAE',           'interest'=>'Automation',       'submitted_at'=>'2026-05-14 08:55','status'=>'new'],
    ];
}

// Interest breakdown
$breakdown = ['Virtual Assistant'=>0,'Demo'=>0,'Prototyping'=>0,'Analytics'=>0,'Automation'=>0];
if ($db_ok) {
    $conn2 = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn2->connect_error) {
        $r = $conn2->query("SELECT interest, COUNT(*) as cnt FROM enquiries GROUP BY interest");
        if ($r) while ($row = $r->fetch_assoc()) {
            $key = ucwords(str_replace('_',' ',$row['interest']));
            $breakdown[$key] = (int)$row['cnt'];
        }
        $conn2->close();
    }
}
if (array_sum($breakdown) === 0) {
    $breakdown = ['Virtual Assistant'=>18,'Demo'=>12,'Prototyping'=>8,'Analytics'=>5,'Automation'=>4];
}

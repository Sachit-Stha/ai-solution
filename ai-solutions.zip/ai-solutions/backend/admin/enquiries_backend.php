<?php
// backend/admin/enquiries_backend.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: ../login.php'); exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$message_alert = '';
$view_item     = null;
$enquiries     = [];

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete']) && $db_ok) {
    $stmt = $conn->prepare("DELETE FROM enquiries WHERE id=?");
    $stmt->bind_param('i', (int)$_GET['delete']);
    $stmt->execute();
    $stmt->close();
    $message_alert = 'Enquiry deleted successfully.';
}

// Handle mark as read
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read']) && $db_ok) {
    $stmt = $conn->prepare("UPDATE enquiries SET status='read' WHERE id=?");
    $stmt->bind_param('i', (int)$_GET['mark_read']);
    $stmt->execute();
    $stmt->close();
    $message_alert = 'Marked as read.';
}

// View single enquiry
if (isset($_GET['view']) && is_numeric($_GET['view']) && $db_ok) {
    $stmt = $conn->prepare("SELECT * FROM enquiries WHERE id=? LIMIT 1");
    $stmt->bind_param('i', (int)$_GET['view']);
    $stmt->execute();
    $view_item = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($view_item) {
        $upd = $conn->prepare("UPDATE enquiries SET status='read' WHERE id=?");
        $upd->bind_param('i', (int)$_GET['view']);
        $upd->execute();
        $upd->close();
    }
}

// Fetch all enquiries
if ($db_ok) {
    $r = $conn->query("SELECT * FROM enquiries ORDER BY submitted_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $enquiries[] = $row;
    $conn->close();
}

// Demo fallback
if (empty($enquiries)) {
    $enquiries = [
        ['id'=>6,'name'=>'Priya Sharma',    'email'=>'priya@techcorp.in',      'phone'=>'+91 98765 43210','company'=>'TechCorp India', 'country'=>'India',         'job_title'=>'CTO',                   'interest'=>'virtual_assistant','job_details'=>'We need an AI assistant to handle 5,000+ daily queries.','submitted_at'=>'2026-05-18 14:22:00','status'=>'new'],
        ['id'=>5,'name'=>'James Wilson',    'email'=>'james@brightpath.co.uk', 'phone'=>'+44 7911 123456','company'=>'BrightPath UK',  'country'=>'United Kingdom','job_title'=>'Head of Digital',        'interest'=>'demo',             'job_details'=>'Interested in a demo for our HR department.',            'submitted_at'=>'2026-05-17 09:45:00','status'=>'read'],
        ['id'=>4,'name'=>'Li Wei',          'email'=>'liwei@horizontech.sg',   'phone'=>'+65 9123 4567', 'company'=>'Horizon Tech',   'country'=>'Singapore',     'job_title'=>'Product Manager',        'interest'=>'prototyping',      'job_details'=>'Need a rapid prototype for an internal tool.',           'submitted_at'=>'2026-05-16 16:30:00','status'=>'read'],
        ['id'=>3,'name'=>'Maria Santos',    'email'=>'maria@novagroup.us',     'phone'=>'+1 555 987 6543','company'=>'NovaGroup',      'country'=>'United States', 'job_title'=>'Director of Operations', 'interest'=>'analytics',        'job_details'=>'Looking for analytics to consolidate our sales data.',   'submitted_at'=>'2026-05-15 11:10:00','status'=>'read'],
        ['id'=>2,'name'=>'Ahmed Al-Rashid', 'email'=>'ahmed@gulfsolutions.ae', 'phone'=>'+971 50 123 456','company'=>'Gulf Solutions', 'country'=>'UAE',           'job_title'=>'CEO',                   'interest'=>'automation',       'job_details'=>'Want to automate invoice processing.',                   'submitted_at'=>'2026-05-14 08:55:00','status'=>'new'],
        ['id'=>1,'name'=>'Sophie Martin',   'email'=>'sophie@innovatefr.fr',   'phone'=>'+33 6 12 34 56', 'company'=>'Innovate France','country'=>'France',        'job_title'=>'Innovation Lead',        'interest'=>'virtual_assistant','job_details'=>'Exploring AI chatbots for our IT helpdesk.',              'submitted_at'=>'2026-05-13 15:20:00','status'=>'read'],
    ];
}

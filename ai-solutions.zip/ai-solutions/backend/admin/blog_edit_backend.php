<?php
// backend/admin/blog_edit_backend.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: ../login.php'); exit;
}

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

$id      = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : 0;
$is_edit = false;
$error   = '';
$success = '';
$post    = [
    'id'=>0,'title'=>'','slug'=>'','excerpt'=>'',
    'content'=>'','category'=>'General',
    'author'=>'AI-Solutions Team','image_emoji'=>'📝','status'=>'draft'
];

// Load post if editing
if ($id && $db_ok) {
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id=? LIMIT 1");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $found = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($found) { $post = $found; $is_edit = true; }
}

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $db_ok) {
    $title   = trim($_POST['title']        ?? '');
    $slug    = trim($_POST['slug']         ?? '');
    $excerpt = trim($_POST['excerpt']      ?? '');
    $content = trim($_POST['content']      ?? '');
    $cat     = trim($_POST['category']     ?? 'General');
    $author  = trim($_POST['author']       ?? 'AI-Solutions Team');
    $emoji   = trim($_POST['image_emoji']  ?? '📝');
    $status  = ($_POST['status'] ?? 'draft') === 'published' ? 'published' : 'draft';

    // Auto-generate slug
    if (empty($slug) && !empty($title)) {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
        $slug = trim($slug, '-');
    }

    if (empty($title) || empty($content)) {
        $error = 'Title and content are required.';
    } else {
        if ($is_edit) {
            $stmt = $conn->prepare(
                "UPDATE blog_posts SET title=?,slug=?,excerpt=?,content=?,category=?,author=?,image_emoji=?,status=?,updated_at=NOW() WHERE id=?"
            );
            $stmt->bind_param('ssssssssi', $title,$slug,$excerpt,$content,$cat,$author,$emoji,$status,$id);
        } else {
            $stmt = $conn->prepare(
                "INSERT INTO blog_posts (title,slug,excerpt,content,category,author,image_emoji,status,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())"
            );
            $stmt->bind_param('ssssssss', $title,$slug,$excerpt,$content,$cat,$author,$emoji,$status);
        }
        if ($stmt->execute()) {
            $new_id = $is_edit ? $id : $conn->insert_id;
            header("Location: blog_edit.php?id={$new_id}&saved=1");
            exit;
        } else {
            $error = 'Save failed: ' . $stmt->error;
        }
        $stmt->close();
    }
    // Repopulate form on error
    $post = array_merge($post, [
        'title'=>$title,'slug'=>$slug,'excerpt'=>$excerpt,
        'content'=>$content,'category'=>$cat,'author'=>$author,
        'image_emoji'=>$emoji,'status'=>$status
    ]);
}

if (isset($_GET['saved'])) {
    $success = $is_edit ? 'Post updated successfully!' : 'Post created successfully!';
}

if ($db_ok) $conn->close();

// Options
$categories = ['AI Technology','Product Development','Automation','Industry Insights','General','Company News'];
$emojis     = ['📝','🤖','⚡','🔄','📊','🔒','🌐','🧠','💡','🎯','🚀','🏆'];

<?php
// backend/post_backend.php
// Handles all backend logic for blog/post.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$slug = trim($_GET['slug'] ?? '');
if (empty($slug)) { header('Location: ../blog.php'); exit; }

$post    = null;
$related = [];

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

if ($db_ok) {
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE slug=? AND status='published' LIMIT 1");
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $post = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($post) {
        $stmt2 = $conn->prepare(
            "SELECT id,title,slug,excerpt,category,image_emoji,created_at
             FROM blog_posts WHERE status='published' AND id != ?
             ORDER BY created_at DESC LIMIT 3"
        );
        $stmt2->bind_param('i', $post['id']);
        $stmt2->execute();
        $r = $stmt2->get_result();
        while ($row = $r->fetch_assoc()) $related[] = $row;
        $stmt2->close();
    }
    $conn->close();
}

// Demo fallback
if (!$post) {
    $demos = [
        'ai-virtual-assistants-transforming-customer-support' => [
            'title'=>'How AI Virtual Assistants Are Transforming Customer Support',
            'excerpt'=>'Discover how AI-powered virtual assistants are helping businesses reduce response times by up to 70%.',
            'content'=>'<p>The landscape of customer support has changed dramatically. AI-powered virtual assistants now handle thousands of simultaneous conversations 24/7.</p><h2>The Problem with Traditional Support</h2><p>Traditional support relies on human agents available only during business hours, creating frustration and long queues.</p><h2>How AI Assistants Change Everything</h2><p>AI assistants understand natural language, remember context, and resolve most queries without human intervention.</p><h2>Real Results</h2><p>Our clients report response time reductions of up to 70%. One enterprise client now resolves over 80% of all incoming queries autonomously.</p>',
            'category'=>'AI Technology','author'=>'AI-Solutions Team','image_emoji'=>'🤖','created_at'=>'2026-05-10 09:00:00',
        ],
        'rapid-prototyping-with-ai' => [
            'title'=>'Rapid Prototyping with AI: From Idea to Working Product in Days',
            'excerpt'=>'Learn how AI-assisted development enables teams to go from concept to prototype faster.',
            'content'=>'<p>Speed is everything in today\'s competitive market. AI-assisted prototyping combines your team\'s expertise with the speed of AI tools.</p><h2>Our Approach</h2><p>At AI-Solutions, we deliver working products within five to ten business days using iterative development sprints and daily client check-ins.</p>',
            'category'=>'Product Development','author'=>'AI-Solutions Team','image_emoji'=>'⚡','created_at'=>'2026-05-05 10:30:00',
        ],
    ];
    $post = $demos[$slug] ?? null;
    if (!$post) { header('Location: ../blog.php'); exit; }
    $post['slug'] = $slug;
}

// Category colours
$cat_colors = [
    'AI Technology'       => ['bg'=>'#dbeafe','color'=>'#1d4ed8'],
    'Product Development' => ['bg'=>'#fce7f3','color'=>'#9d174d'],
    'Automation'          => ['bg'=>'#d1fae5','color'=>'#065f46'],
    'Industry Insights'   => ['bg'=>'#fef9c3','color'=>'#854d0e'],
    'General'             => ['bg'=>'#e0f2fe','color'=>'#0369a1'],
];
$cc = $cat_colors[$post['category']] ?? ['bg'=>'#f1f5f9','color'=>'#475569'];

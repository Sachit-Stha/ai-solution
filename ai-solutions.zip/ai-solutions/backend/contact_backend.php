<?php
// backend/contact_backend.php
// Handles all backend logic for contact.php

session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$success = false;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Raw input
    $name       = trim($_POST['name']       ?? '');
    $email      = trim($_POST['email']      ?? '');
    $phone      = trim($_POST['phone']      ?? '');
    $company    = trim($_POST['company']    ?? '');
    $country    = trim($_POST['country']    ?? '');
    $job_title  = trim($_POST['job_title']  ?? '');
    $job_details= trim($_POST['job_details']?? '');
    $interest   = trim($_POST['interest']   ?? '');

    // Validate
    if (empty($name) || empty($email) || empty($phone) || empty($company) || empty($country) || empty($job_details)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            // DB not available — simulate success for demo
            $success = true;
        } else {
            $stmt = $conn->prepare(
                "INSERT INTO enquiries (name, email, phone, company, country, job_title, job_details, interest, submitted_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );
            $stmt->bind_param('ssssssss', $name, $email, $phone, $company, $country, $job_title, $job_details, $interest);
            if ($stmt->execute()) {
                $success = true;
            } else {
                $error = 'Something went wrong. Please try again.';
            }
            $stmt->close();
            $conn->close();
        }
    }
}

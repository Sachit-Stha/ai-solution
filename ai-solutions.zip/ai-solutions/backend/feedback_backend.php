<?php
// backend/feedback_backend.php
// Handles all backend logic for feedback.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$success        = false;
$error          = '';
$recent_reviews = [];
$avg_rating     = 0;
$total_reviews  = 0;

// Connect once
$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

// Handle POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']    ?? '');
    $email   = trim($_POST['email']   ?? '');
    $company = trim($_POST['company'] ?? '');
    $rating  = (int)($_POST['rating'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || $rating < 1 || $rating > 5 || empty($message)) {
        $error = 'Please fill in your name, a rating, and a message.';
    } elseif (!$db_ok) {
        $error = 'Database connection failed. Please try again later.';
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO feedback (name, email, company, rating, message, submitted_at)
             VALUES (?, ?, ?, ?, ?, NOW())"
        );
        $stmt->bind_param('sssis', $name, $email, $company, $rating, $message);
        $success = $stmt->execute();
        if (!$success) $error = 'Could not save your feedback: ' . $stmt->error;
        $stmt->close();
    }
}

// Fetch all reviews
if ($db_ok) {
    $r = $conn->query("SELECT name, company, rating, message FROM feedback ORDER BY submitted_at DESC");
    if ($r) while ($row = $r->fetch_assoc()) $recent_reviews[] = $row;

    $r2 = $conn->query("SELECT COUNT(*) as cnt, ROUND(AVG(rating),1) as avg_r FROM feedback");
    if ($r2) {
        $row2          = $r2->fetch_assoc();
        $total_reviews = (int)$row2['cnt'];
        $avg_rating    = (float)$row2['avg_r'];
    }
    $conn->close();
}

// Fallback demo data if DB empty
if ($total_reviews === 0) {
    $avg_rating    = 4.7;
    $total_reviews = 31;
    $recent_reviews = [
        ['name'=>'Priya S.',  'company'=>'TechCorp India','rating'=>5,'message'=>'The virtual assistant exceeded our expectations. Response times are incredible.'],
        ['name'=>'James W.',  'company'=>'BrightPath UK', 'rating'=>5,'message'=>'Outstanding service from start to finish. Delivered on time and on budget.'],
        ['name'=>'Li W.',     'company'=>'Horizon Tech',  'rating'=>4,'message'=>'Very impressed with the prototyping speed. Overall an excellent experience.'],
        ['name'=>'Maria S.',  'company'=>'NovaGroup',     'rating'=>5,'message'=>'AI-Solutions completely transformed how we handle customer data!'],
    ];
}

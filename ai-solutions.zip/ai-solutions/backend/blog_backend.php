<?php
// backend/blog_backend.php
// Handles all backend logic for blog.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_solutions_db');

$db_posts      = [];
$categories    = [];
$selected_cat  = trim($_GET['cat'] ?? '');

$conn  = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db_ok = !$conn->connect_error;

if ($db_ok) {
    // Fetch categories
    $r = $conn->query("SELECT DISTINCT category FROM blog_posts WHERE status='published' ORDER BY category");
    if ($r) while ($row = $r->fetch_assoc()) $categories[] = $row['category'];

    // Fetch posts (filtered or all)
    if ($selected_cat) {
        $stmt = $conn->prepare(
            "SELECT id,title,slug,excerpt,category,author,image_emoji,created_at
             FROM blog_posts WHERE status='published' AND category=?
             ORDER BY created_at DESC"
        );
        $stmt->bind_param('s', $selected_cat);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query(
            "SELECT id,title,slug,excerpt,category,author,image_emoji,created_at
             FROM blog_posts WHERE status='published'
             ORDER BY created_at DESC"
        );
    }
    if ($result) while ($row = $result->fetch_assoc()) $db_posts[] = $row;
    $conn->close();
}

// Fallback demo posts if DB empty
if (empty($db_posts)) {
    $categories = ['AI Technology','Product Development','Automation','Industry Insights'];
    $db_posts   = [
        ['id'=>1,'title'=>'How AI Virtual Assistants Are Transforming Customer Support','slug'=>'ai-virtual-assistants-transforming-customer-support','excerpt'=>'Discover how AI-powered virtual assistants are helping businesses reduce response times by up to 70%.','category'=>'AI Technology','author'=>'AI-Solutions Team','image_emoji'=>'🤖','created_at'=>'2026-05-10 09:00:00'],
        ['id'=>2,'title'=>'Rapid Prototyping with AI: From Idea to Working Product in Days','slug'=>'rapid-prototyping-with-ai','excerpt'=>'Learn how AI-assisted development enables teams to go from concept to working prototype faster.','category'=>'Product Development','author'=>'AI-Solutions Team','image_emoji'=>'⚡','created_at'=>'2026-05-05 10:30:00'],
        ['id'=>3,'title'=>'Top 5 Business Processes You Should Automate Right Now','slug'=>'top-5-business-processes-to-automate','excerpt'=>'Not sure where to start with automation? Here are five processes that deliver the highest ROI.','category'=>'Automation','author'=>'AI-Solutions Team','image_emoji'=>'🔄','created_at'=>'2026-04-28 14:00:00'],
        ['id'=>4,'title'=>'Understanding AI Ethics in Enterprise Software','slug'=>'understanding-ai-ethics-enterprise-software','excerpt'=>'As AI becomes embedded in enterprise workflows, understanding ethical implications is more important than ever.','category'=>'Industry Insights','author'=>'AI-Solutions Team','image_emoji'=>'🧠','created_at'=>'2026-04-15 11:00:00'],
    ];
}

// Category badge colours
$cat_colors = [
    'AI Technology'       => ['bg'=>'#dbeafe','color'=>'#1d4ed8'],
    'Product Development' => ['bg'=>'#fce7f3','color'=>'#9d174d'],
    'Automation'          => ['bg'=>'#d1fae5','color'=>'#065f46'],
    'Industry Insights'   => ['bg'=>'#fef9c3','color'=>'#854d0e'],
    'General'             => ['bg'=>'#e0f2fe','color'=>'#0369a1'],
];

function catStyle($cat, $colors) {
    $c = $colors[$cat] ?? ['bg'=>'#f1f5f9','color'=>'#475569'];
    return "background:{$c['bg']};color:{$c['color']}";
}

<?php
// FRONTEND: blog/post.php
// Backend logic is separated into backend/post_backend.php
require_once '../backend/post_backend.php';
$pageTitle = $post['title'] . ' – AI-Solutions Blog';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="../css/style.css">
<style>
.post-hero-thumb{height:280px;background:linear-gradient(135deg,#1a3c6e,#0e7490);display:flex;align-items:center;justify-content:center;font-size:7rem}
.post-body{max-width:760px;margin:0 auto}
.post-body h2{font-size:1.5rem;font-weight:800;color:var(--primary);margin:2rem 0 .75rem}
.post-body h3{font-size:1.2rem;font-weight:700;color:var(--primary);margin:1.5rem 0 .6rem}
.post-body p{color:var(--muted);line-height:1.8;margin-bottom:1.1rem}
.post-body ul,.post-body ol{margin:.5rem 0 1.1rem 1.5rem;color:var(--muted);line-height:1.8}
.post-body li{margin-bottom:.4rem}
.post-body blockquote{border-left:4px solid var(--pl);padding:.75rem 1.2rem;background:#f0f7ff;border-radius:0 8px 8px 0;margin:1.5rem 0;font-style:italic;color:var(--muted)}
.related-card{background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:1.2rem;display:flex;gap:1rem;align-items:flex-start;text-decoration:none;transition:.2s}
.related-card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.related-card .thumb{font-size:2rem;flex-shrink:0;width:50px;height:50px;background:#e0f2fe;border-radius:10px;display:flex;align-items:center;justify-content:center}
.related-card h4{font-size:.9rem;font-weight:700;color:var(--primary);margin-bottom:.3rem;line-height:1.4}
.related-card span{font-size:.78rem;color:var(--muted)}
</style>
</head>
<body>

<?php include '../includes/nav.php'; ?>

<div class="post-hero-thumb"><?= $post['image_emoji'] ?></div>

<section>
  <div class="section-inner">
    <div class="post-body">

      <div style="font-size:.85rem;color:var(--muted);margin-bottom:1.5rem">
        <a href="../index.php" style="color:var(--muted);text-decoration:none">Home</a> /
        <a href="../blog.php" style="color:var(--muted);text-decoration:none">Blog</a> /
        <span style="color:var(--text)"><?= htmlspecialchars(mb_strimwidth($post['title'],0,40,'...')) ?></span>
      </div>

      <div style="margin-bottom:1rem">
        <span style="display:inline-block;background:<?= $cc['bg'] ?>;color:<?= $cc['color'] ?>;font-size:.75rem;font-weight:700;padding:.25rem .75rem;border-radius:50px">
          <?= htmlspecialchars($post['category']) ?>
        </span>
      </div>

      <h1 style="font-size:clamp(1.6rem,3.5vw,2.4rem);font-weight:800;color:var(--primary);line-height:1.25;margin-bottom:1rem">
        <?= htmlspecialchars($post['title']) ?>
      </h1>

      <div style="display:flex;align-items:center;gap:1rem;padding-bottom:1.5rem;border-bottom:1px solid var(--border);margin-bottom:2rem;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:.5rem">
          <div style="width:32px;height:32px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.8rem">AI</div>
          <span style="font-size:.88rem;font-weight:600;color:var(--text)"><?= htmlspecialchars($post['author']) ?></span>
        </div>
        <span style="color:var(--muted);font-size:.85rem">📅 <?= date('F j, Y',strtotime($post['created_at'])) ?></span>
      </div>

      <div class="post-body"><?= $post['content'] ?></div>

      <div style="margin-top:3rem;padding:2rem;background:linear-gradient(135deg,var(--primary),#1e4d8c);border-radius:14px;color:#fff;text-align:center">
        <h3 style="font-size:1.3rem;font-weight:800;margin-bottom:.6rem">Ready to get started?</h3>
        <p style="opacity:.85;margin-bottom:1.2rem;font-size:.95rem">Talk to our team about how AI-Solutions can help your business.</p>
        <a href="../contact.php" class="btn btn-primary" style="background:#fff;color:var(--primary)">Contact Us Today →</a>
      </div>

      <div style="margin-top:2rem;text-align:center">
        <a href="../blog.php" style="color:var(--pl);font-weight:600;text-decoration:none;font-size:.95rem">← Back to Blog</a>
      </div>
    </div>
  </div>
</section>

<?php if (!empty($related)): ?>
<section class="bg-light" style="padding:3rem 2rem">
  <div class="section-inner">
    <h2 style="font-size:1.2rem;font-weight:800;color:var(--primary);margin-bottom:1.5rem">More Articles</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1rem">
      <?php foreach ($related as $rel): ?>
      <a href="post.php?slug=<?= urlencode($rel['slug']) ?>" class="related-card">
        <div class="thumb"><?= $rel['image_emoji'] ?></div>
        <div>
          <h4><?= htmlspecialchars($rel['title']) ?></h4>
          <span><?= date('M j, Y',strtotime($rel['created_at'])) ?></span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
</body>
</html>

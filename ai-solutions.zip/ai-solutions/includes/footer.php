<?php // includes/footer.php ?>
<footer>
  <div class="footer-inner">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="footer-logo">
          <div class="logo-icon" style="width:32px;height:32px;font-size:14px;flex-shrink:0">AI</div>
          AI-Solutions
        </div>
        <p>Leveraging AI to rapidly and proactively address issues that impact the digital employee experience. Innovating the future of work.</p>
      </div>
      <div class="footer-col">
        <h4>Company</h4>
        <ul>
          <li><a href="/ai-solutions/index.html">Home</a></li>
          <li><a href="/ai-solutions/services.html">Services</a></li>
          <li><a href="/ai-solutions/gallery.html">Gallery</a></li>
          <li><a href="/ai-solutions/blog.html">Blog</a></li>
          <li><a href="/ai-solutions/feedback.html">Feedback</a></li>
          <li><a href="/ai-solutions/contact.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Solutions</h4>
        <ul>
          <li><a href="/ai-solutions/services.html">Virtual Assistant</a></li>
          <li><a href="/ai-solutions/services.html">AI Prototyping</a></li>
          <li><a href="/ai-solutions/services.html">Process Automation</a></li>
          <li><a href="/ai-solutions/services.html">Analytics</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="mailto:info@ai-solutions.com">info@ai-solutions.com</a></li>
          <li><a href="tel:+441915000000">+44 191 500 0000</a></li>
          <li><a href="#">Sunderland, UK</a></li>
          <li><a href="/ai-solutions/admin/login.html">Admin Login</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> AI-Solutions Ltd. All rights reserved.</span>
      <span>CET333 Product Development</span>
    </div>
  </div>
</footer>

<script src="<?= (strpos($_SERVER['PHP_SELF'], '/admin/') !== false || strpos($_SERVER['PHP_SELF'], '/blog/') !== false) ? '../' : '' ?>js/main.js"></script>

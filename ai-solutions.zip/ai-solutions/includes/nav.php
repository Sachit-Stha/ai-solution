<?php
// includes/nav.php - shared navigation
$current = basename($_SERVER['PHP_SELF'], '.php');
$in_admin = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
$in_blog  = strpos($_SERVER['PHP_SELF'], '/blog/')  !== false;
$root = ($in_admin || $in_blog) ? '../' : '';
?>
<nav>
  <a href="/ai-solutions/index.html" class="nav-logo">
    <div class="logo-icon">AI</div>
    <span>AI-Solutions</span>
  </a>
  <ul class="nav-links" id="navLinks">
    <li><a href="/ai-solutions/index.html" <?= ($current==='index')?'class="active"':'' ?>>Home</a></li>
    <li><a href="/ai-solutions/services.html" <?= ($current==='services')?'class="active"':'' ?>>Services</a></li>
    <li><a href="/ai-solutions/gallery.html" <?= ($current==='gallery')?'class="active"':'' ?>>Gallery</a></li>
    <li><a href="/ai-solutions/blog.html" <?= ($current==='blog')?'class="active"':'' ?>>Blog</a></li>
    <li><a href="/ai-solutions/feedback.html" <?= ($current==='feedback')?'class="active"':'' ?>>Feedback</a></li>
    <li><a href="/ai-solutions/contact.html" class="nav-cta <?= ($current==='contact')?'active':'' ?>">Contact Us</a></li>
  </ul>
  <button class="hamburger" id="hamburger" aria-label="Toggle menu">
    <span></span><span></span><span></span>
  </button>
</nav>

<!-- Chatbot Widget -->
<div class="chatbot-wrapper">
  <div class="chat-window" id="chatWindow">
    <div class="chat-header">
      <div class="chat-avatar">🤖</div>
      <div class="chat-header-info">
        <strong>Aria – AI Assistant</strong>
        <span>● Online now</span>
      </div>
      <button class="chat-close-btn" id="chatClose" aria-label="Close chat">✕</button>
    </div>
    <div class="chat-messages" id="chatMessages">
      <div class="msg bot">👋 Hi! I'm Aria, AI-Solutions' virtual assistant. How can I help you today?</div>
    </div>
    <div class="chat-quick-btns">
      <button class="quick-btn" data-q="Tell me about your services">Our services</button>
      <button class="quick-btn" data-q="I want to schedule a demo">Schedule demo</button>
      <button class="quick-btn" data-q="How do I contact the team?">Contact us</button>
      <button class="quick-btn" data-q="Tell me about upcoming events">Events</button>
      <button class="quick-btn" data-q="What is the pricing?">Pricing</button>
      <button class="quick-btn" data-q="I want to join promotional events">Join events</button>
      <button class="quick-btn" data-q="What industries do you work with?">Industries</button>
      <button class="quick-btn" data-q="Can I speak to a human?">Talk to a human</button>
      <button class="quick-btn" data-q="Where are you located?">Location</button>
      <button class="quick-btn" data-q="Do you offer support after delivery?">Support</button>
    </div>
    <div class="chat-input-row">
      <input type="text" id="chatInput" placeholder="Type a message…" autocomplete="off">
      <button class="chat-send" id="chatSend" aria-label="Send">&#10148;</button>
    </div>
  </div>
  <button class="chat-toggle" id="chatToggle" aria-label="Open chat">
    💬
    <span class="chat-pulse"></span>
  </button>
</div>

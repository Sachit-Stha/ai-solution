<?php
$pageTitle = "Our Services – AI-Solutions";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/nav.php'; ?>

<div class="page-hero">
  <div class="breadcrumb"><a href="index.php">Home</a> / Services</div>
  <h1>Our AI-Powered Solutions</h1>
  <p>Cutting-edge software solutions designed to transform your digital employee experience.</p>
</div>

<!-- SERVICES DETAIL -->
<section>
  <div class="section-inner">

    <div class="service-detail">
      <div class="service-detail-visual">🤖</div>
      <div>
        <span class="service-tag">Virtual Assistant</span>
        <h2>AI-Powered Virtual Assistant</h2>
        <p>Deploy an intelligent virtual assistant that understands natural language, resolves queries instantly, and escalates complex cases to your human team seamlessly. Our AI assistant works 24/7 across web, mobile, and messaging platforms.</p>
        <p>Built on state-of-the-art language models, it learns from every interaction to continuously improve its accuracy and helpfulness.</p>
        <ul class="feature-list">
          <li>Natural language understanding and contextual replies</li>
          <li>Seamless human handoff when complexity requires it</li>
          <li>Integrates with CRM, helpdesk, and ticketing systems</li>
          <li>Multi-language support across 50+ languages</li>
          <li>Analytics dashboard showing resolution rates and trends</li>
        </ul>
        <br><a href="contact.php" class="btn btn-dark" style="display:inline-flex">Get Started →</a>
      </div>
    </div>

    <div class="service-detail reverse">
      <div class="service-detail-visual" style="background:linear-gradient(135deg,#fce7f3,#fbcfe8)">⚡</div>
      <div>
        <span class="service-tag" style="background:#fce7f3;color:#9d174d">Rapid Prototyping</span>
        <h2>AI-Assisted Rapid Prototyping</h2>
        <p>We leverage AI to dramatically accelerate the product development lifecycle. From concept to working prototype in days — our process combines AI-generated scaffolding with expert engineering to deliver high-quality results at speed.</p>
        <p>Our prototyping methodology has helped clients reduce their typical time-to-market by up to 60%, while maintaining rigorous quality standards.</p>
        <ul class="feature-list">
          <li>Concept-to-prototype in as few as 5 business days</li>
          <li>AI-generated code scaffolding and architecture</li>
          <li>Iterative refinement with continuous client feedback</li>
          <li>Full handoff including documentation and source code</li>
          <li>Optional ongoing development and maintenance</li>
        </ul>
        <br><a href="contact.php" class="btn btn-dark" style="display:inline-flex">Get Started →</a>
      </div>
    </div>

    <div class="service-detail">
      <div class="service-detail-visual" style="background:linear-gradient(135deg,#d1fae5,#a7f3d0)">🔄</div>
      <div>
        <span class="service-tag" style="background:#d1fae5;color:#065f46">Automation</span>
        <h2>Intelligent Process Automation</h2>
        <p>Identify, map, and automate your most time-consuming business processes using AI-powered robotic process automation (RPA) and workflow orchestration. Free your workforce to focus on strategic, high-value activities.</p>
        <ul class="feature-list">
          <li>Process discovery and bottleneck analysis</li>
          <li>AI-powered RPA bots for repetitive workflows</li>
          <li>Document processing and data extraction</li>
          <li>Exception handling with human-in-the-loop controls</li>
          <li>ROI reporting and time-savings dashboards</li>
        </ul>
        <br><a href="contact.php" class="btn btn-dark" style="display:inline-flex">Get Started →</a>
      </div>
    </div>

    <div class="service-detail reverse">
      <div class="service-detail-visual" style="background:linear-gradient(135deg,#fef9c3,#fde68a)">📊</div>
      <div>
        <span class="service-tag" style="background:#fef9c3;color:#854d0e">Analytics</span>
        <h2>AI Analytics &amp; Insights</h2>
        <p>Transform raw data into strategic intelligence. Our AI analytics platform ingests data from multiple sources, identifies patterns, and surfaces actionable insights through intuitive dashboards — no data science degree required.</p>
        <ul class="feature-list">
          <li>Real-time dashboards and KPI tracking</li>
          <li>Predictive analytics and trend forecasting</li>
          <li>Natural language data querying ("Ask your data")</li>
          <li>Anomaly detection and automated alerts</li>
          <li>Integrates with 100+ data sources</li>
        </ul>
        <br><a href="contact.php" class="btn btn-dark" style="display:inline-flex">Get Started →</a>
      </div>
    </div>

  </div>
</section>

<!-- TECH STACK -->
<section class="bg-light">
  <div class="section-inner">
    <div class="section-header" style="text-align:center">
      <div class="section-tag">Technologies</div>
      <h2 class="section-title">Built on Proven Technology</h2>
      <p class="section-sub" style="margin:0 auto">We use industry-leading tools and frameworks to build reliable, scalable solutions.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:1rem;text-align:center">
      <?php
      $techs = ['🧠 GPT / LLM','☁️ Cloud Native','🐍 Python','⚛️ React','🐳 Docker','🔐 OAuth 2.0','📡 REST API','🗄️ PostgreSQL','📊 Power BI','🤖 TensorFlow'];
      foreach ($techs as $t): ?>
      <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:1.2rem .5rem;font-size:.85rem;font-weight:600;color:var(--primary)"><?= $t ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<div class="cta-banner">
  <h2>Ready to Get Started?</h2>
  <p>Tell us about your project and we'll get back to you within 24 hours.</p>
  <a href="contact.php" class="btn" style="background:#fff;color:var(--primary);font-weight:700">Contact Us Today →</a>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>
